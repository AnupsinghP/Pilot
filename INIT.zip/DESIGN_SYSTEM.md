# PureNest Design System & Style Guide

A comprehensive design documentation for the **PureNest** home cleaning mobile web application, tailored for the premium Indian domestic services market.

---

## 1. Design Overview & Philosophy

PureNest blends **contemporary minimalist Scandinavian/Japandi domestic calmness** with **organic, classical Indian design nuances**. Built specifically for high-end urban households (e.g., Mumbai, Bangalore, NCR), the design rejects clinical or sterile utility interfaces in favor of warmth, domestic trust, and tactile luxury.

### Core Architectural Principles
* **Organic Classical Indian Accents**: A subtle geometric *jaali* / mandala lattice pattern (`.bg-indian-motif`) is layered with low opacity across the device canvases, referencing traditional Indian architectural latticework without visual noise.
* **Warm, Natural Materiality**: Neutral tones are infused with linen, terracotta, sand, and turmeric undertones rather than pure cold greys or harsh blues.
* **Editorial & High-Trust Hierarchy**: Paired display serif headings (`Playfair Display`) with clean modern geometric sans (`Plus Jakarta Sans`) to project hotel-grade concierge dependability.
* **Culturally Grounded Logistics**: Native localization including Indian Rupee (`₹`) pricing tiers, society guard / MyGate access notes, kitchen chimney & exhaust degreasing, and seasonal festive resets (Diwali & Navratri).

---

## 2. Typography

The application relies on two Google Fonts configured in `index.html` and Tailwind theme configurations:

| Role | Font Family | Weights | Tailwind Classes | Purpose |
| :--- | :--- | :--- | :--- | :--- |
| **Editorial Headings** | `Playfair Display` | 500, 600, 400 italic | `font-serif tracking-tight` | Conveys artisanal care, high-end hospitality, and boutique elegance. |
| **Body & UI Elements** | `Plus Jakarta Sans` | 300, 400, 500, 600, 700 | `font-sans` | Crisp readability on high-density mobile screens; navigation & stats. |

---

## 3. Four Core Design Themes

PureNest features four distinct dynamic themes switchable on the fly via `ThemeContext` (`/src/context/ThemeContext.tsx`).

### Theme 1: Warm Sandstone (Recommended Default)
* **Subtitle**: *Jaipur Terracotta & Organic Linen*
* **Tagline**: Mindful, calming, tactile warmth
* **Emotional Vibe**: Warm, grounding, peaceful, understated elegance
* **Target Audience**: Premium homeowners seeking mindful living, organic non-toxic cleaning, and trusted quiet care.
* **Corner Radius**: Cards: `rounded-2xl` (16px), Buttons: `rounded-xl` (12px)

#### Swatches & Color Tokens
| Token | Hex / Class | Description |
| :--- | :--- | :--- |
| **Primary Swatch** | `#292524` | Warm Espresso Charcoal |
| **Secondary Swatch** | `#57534E` | Muted Stone Charcoal |
| **Accent Swatch** | `#059669` | Calming Jade / Emerald |
| **Background Swatch** | `#F4F1EA` | Organic Warm Sandstone |
| `bgPage` | `bg-[#F4F1EA]` | Outer canvas background |
| `bgPhone` | `bg-[#FAF8F5]` | Device inner canvas |
| `bgCard` | `bg-white` | Elevated card surfaces |
| `bgCardSubtle` | `bg-[#F2EFE9]` | Subdued card containers |
| `bgCardMuted` | `bg-[#EAE5DC]` | Inactive / secondary panels |
| `borderPrimary` | `border-[#E4DED4]` | Standard card outlines |
| `borderSubtle` | `border-[#EDE8E0]` | Hairline dividers |
| `textPrimary` | `text-[#292524]` | High-contrast body & titles |
| `textSecondary` | `text-[#57534E]` | Secondary descriptions |
| `textMuted` | `text-[#78716C]` | Captions & subtle labels |
| `accentPrimary` | `bg-[#292524]` | Primary CTA button fill |
| `accentHover` | `hover:bg-[#1C1917]` | Button hover interaction |
| `accentBgSubtle` | `bg-[#EFECE6]` | Pill & badge backgrounds |
| `highlightGreen` | `text-emerald-700` | Eco-friendly / verified tags |
| `highlightGold` | `text-amber-800` | Rating & prestige highlights |

---

### Theme 2: Monsoon Minimalist
* **Subtitle**: *Deep Teal & Monsoon Cloud*
* **Tagline**: Lush, restorative tropical serenity
* **Emotional Vibe**: Crisp, modern, authoritative, lightning-fast
* **Target Audience**: Tech professionals in Bangalore, Hyderabad, & Gurgaon demanding on-demand speed and clinical precision.
* **Corner Radius**: Cards: `rounded-xl` (12px), Buttons: `rounded-lg` (8px)

#### Swatches & Color Tokens
| Token | Hex / Class | Description |
| :--- | :--- | :--- |
| **Primary Swatch** | `#0F172A` | Deep Monsoon Slate |
| **Secondary Swatch** | `#0F766E` | Deep Tropical Teal |
| **Accent Swatch** | `#0284C7` | Vivid Sky / Rain Blue |
| **Background Swatch** | `#F8FAFC` | Alabaster Cloud |
| `bgPage` | `bg-[#EEF2F6]` | Outer canvas background |
| `bgPhone` | `bg-[#F8FAFC]` | Device inner canvas |
| `bgCard` | `bg-white` | Elevated card surfaces |
| `bgCardSubtle` | `bg-[#F1F5F9]` | Subtle slate card surfaces |
| `bgCardMuted` | `bg-[#E2E8F0]` | Neutral grey divider fills |
| `borderPrimary` | `border-[#CBD5E1]` | Card outlines |
| `borderSubtle` | `border-[#E2E8F0]` | Inner row dividers |
| `textPrimary` | `text-[#0F172A]` | Primary heading and text |
| `textSecondary` | `text-[#334155]` | Subtitles |
| `textMuted` | `text-[#64748B]` | Metadata & timestamps |
| `accentPrimary` | `bg-[#0F172A]` | Primary action buttons |
| `accentBgSubtle` | `bg-[#E0F2FE]` | Light rain accent pills |
| `highlightGreen` | `text-teal-600` | Verification markers |
| `highlightGold` | `text-sky-600` | Interactive focus badges |

---

### Theme 3: Festive Marigold
* **Subtitle**: *Warm Turmeric & Celebratory Glow*
* **Tagline**: Vibrant, welcoming, festive readiness
* **Emotional Vibe**: Joyful, culturally resonant, warm, auspicious
* **Target Audience**: Families preparing for Diwali, Navratri, Pooja, and family hosting seeking traditional trust.
* **Corner Radius**: Cards: `rounded-2xl` (16px), Buttons: `rounded-2xl` (16px), Shell: `rounded-3xl` (24px)

#### Swatches & Color Tokens
| Token | Hex / Class | Description |
| :--- | :--- | :--- |
| **Primary Swatch** | `#A63A27` | Rich Kumkum & Terracotta Red |
| **Secondary Swatch** | `#D97706` | Deep Golden Marigold / Turmeric |
| **Accent Swatch** | `#059669` | Festive Mango Leaf Green |
| **Background Swatch** | `#FDFBF7` | Warm Ivory & Raw Silk |
| `bgPage` | `bg-[#F7F3EA]` | Warm festive outer canvas |
| `bgPhone` | `bg-[#FDFBF7]` | Ivory parchment background |
| `bgCard` | `bg-white` | Pure card elevation |
| `bgCardSubtle` | `bg-[#F5F0E6]` | Light marigold/sandalwood tint |
| `bgCardMuted` | `bg-[#EBE2CF]` | Darker parchment borders |
| `borderPrimary` | `border-[#E0D5BC]` | Antique brass border |
| `borderSubtle` | `border-[#EBE2CF]` | Subtle warm divider |
| `textPrimary` | `text-[#4A2C11]` | Rich roasted umber |
| `textSecondary` | `text-[#6E421A]` | Warm earthy cinnamon |
| `textMuted` | `text-[#9A7045]` | Muted copper brown |
| `accentPrimary` | `bg-[#A63A27]` | Auspicious terracotta button |
| `accentHover` | `hover:bg-[#8A2B1A]` | Deepening red state |
| `accentBgSubtle` | `bg-[#FADBD5]` | Rose petal badge background |
| `highlightGreen` | `text-emerald-700` | Organic / eco seal |
| `highlightGold` | `text-amber-600` | Festive marigold tag |

---

### Theme 4: Quiet Luxury (Mumbai)
* **Subtitle**: *Onyx & South Mumbai Elegance*
* **Tagline**: 5-star white-glove hotel standard
* **Emotional Vibe**: Boutique, exclusive, polished, bespoke hotel concierge
* **Target Audience**: High-net-worth homeowners in South Mumbai, Bandra, and luxury penthouses.
* **Corner Radius**: Cards: `rounded-xl` (12px), Buttons: `rounded-lg` (8px)

#### Swatches & Color Tokens
| Token | Hex / Class | Description |
| :--- | :--- | :--- |
| **Primary Swatch** | `#1A1815` | Polished Jet Onyx |
| **Secondary Swatch** | `#9A7332` | Brushed Champagne Gold |
| **Accent Swatch** | `#C5A880` | Soft Cashmere Bronze |
| **Background Swatch** | `#FBF9F6` | Cream Alabaster Silk |
| `bgPage` | `bg-[#EAE6DF]` | Champagne neutral canvas |
| `bgPhone` | `bg-[#FBF9F6]` | Subtle warm porcelain |
| `bgCard` | `bg-white` | Clean white card container |
| `bgCardSubtle` | `bg-[#F3EFE9]` | Light cashmerette container |
| `bgCardMuted` | `bg-[#E6DFD3]` | Darker warm stone trim |
| `borderPrimary` | `border-[#D8CFBF]` | Muted bronze border |
| `borderSubtle` | `border-[#E7E0D3]` | Subtle warm contour |
| `textPrimary` | `text-[#1A1815]` | Deep onyx body & titles |
| `textSecondary` | `text-[#4A443D]` | Charcoal grey subtitle |
| `textMuted` | `text-[#7D756A]` | Warm taupe caption |
| `accentPrimary` | `bg-[#1A1815]` | Onyx button CTA |
| `accentHover` | `hover:bg-[#2C2824]` | Polished dark hover |
| `accentBgSubtle` | `bg-[#F4ECE0]` | Soft champagne pill badge |
| `highlightGreen` | `text-emerald-800` | Prestige certification badge |
| `highlightGold` | `text-[#9A7332]` | Signature metallic champagne |

---

## 4. Classical Indian Touches & Organic Motifs

1. **Jali / Mandala Background Pattern (`.bg-indian-motif`)**:
   - Implemented as a pure inline SVG CSS layer in `src/index.css`:
   ```css
   .bg-indian-motif {
     background-image: url("data:image/svg+xml,%3Csvg width='60' height='60' viewBox='0 0 60 60' xmlns='http://www.w3.org/2000/svg'%3E%3Cg fill='none' fill-rule='evenodd'%3E%3Cg fill='%239C92AC' fill-opacity='0.04'%3E%3Cpath d='M30 0l30 30-30 30L0 30zM15 30l15-15 15 15-15 15z'/%3E%3C/g%3E%3C/g%3E%3C/svg%3E");
   }
   ```
   - Applied cleanly to mobile viewport backgrounds (`DeviceFrame.tsx`), establishing rhythmic micro-texture that feels woven and tactile rather than digital and flat.
2. **Culturally Resonant Add-ons**:
   - **Exhaust & Chimney Degreasing**: Tailored for heavy Indian cooking and masala residues.
   - **Balcony Pressure Scrubbing**: Essential for dust and monsoon maintenance in high-rise apartments.
   - **Festive Pre-Season Deep Clean**: Catering to the annual pre-Diwali deep cleansing ritual.
   - **Gated Community Access**: Native instructions for society security desks, MyGate visitor approval, and guard entry passes.
3. **Currency & Localization**:
   - Standardized on Indian Rupee symbol `₹` across all tiers (e.g., `₹1499`, `₹2999`, `₹15,000`).

---

## 5. Icon System (`lucide-react`)

All iconography is imported from the standardized `lucide-react` library. Icons are grouped below by structural and functional responsibility:

### A. Primary Navigation & Bottom Bar
| Icon | Import | Usage Context |
| :--- | :--- | :--- |
| `Sparkles` | `lucide-react` | Home screen tab & deep cleaning indicators |
| `ShieldCheck` | `lucide-react` | Rental Handover / Move-Out Guarantee screen tab |
| `Leaf` | `lucide-react` | Eco-wellness, HEPA botanical clean, and allergen protection |
| `CalendarClock` | `lucide-react` | Housekeeping Subscription tab & recurring cadence |
| `Activity` | `lucide-react` | Live dispatch tracker tab & real-time ETA updates |
| `Award` | `lucide-react` | Market research & competitive benchmark canvas |

### B. Service & Specialization Features
| Icon | Import | Usage Context |
| :--- | :--- | :--- |
| `Wind` | `lucide-react` | Chimney & exhaust fan degreasing add-on |
| `Flame` | `lucide-react` | Intensive cooking stains & high-power steam clean |
| `Sun` | `lucide-react` | Balcony pressure wash & summer seasonal resets |
| `Snowflake` | `lucide-react` | Post-monsoon moisture & winter allergen deep cleans |
| `Lock` / `Key` | `lucide-react` | Society guard handover & secure apartment entry |
| `Shield` | `lucide-react` | Insurance, verified background checks, damage guarantees |
| `CheckCircle2` / `Check` | `lucide-react` | 100% deposit refund checklists, inspection criteria pass |
| `Star` | `lucide-react` | Professional cleaner rating and customer feedback |
| `Zap` | `lucide-react` | 60-minute express booking & instant dispatch |
| `Gift` | `lucide-react` | Complimentary add-ons and subscription loyalty perks |

### C. Booking, Selection, & Controls
| Icon | Import | Usage Context |
| :--- | :--- | :--- |
| `Calendar` | `lucide-react` | Slot selector, date picker, booking schedule |
| `Clock` | `lucide-react` | Arrival window estimation (e.g., 09:00 - 11:30 AM) |
| `CreditCard` | `lucide-react` | UPI, Net Banking, and Card checkout |
| `MapPin` | `lucide-react` | High-rise building address, tower, and flat selector |
| `Camera` | `lucide-react` | Pre/post cleaning photo inspection proof upload |
| `Plus` / `Minus` | `lucide-react` | BHK room counter and quantity adjustments |
| `RotateCcw` / `Repeat`| `lucide-react` | Subscription rollover, clean rescheduling |
| `Pause` | `lucide-react` | 1-tap subscription pause when traveling |
| `ChevronRight` / `ChevronDown` | `lucide-react` | Expandable checklist drawers & navigation prompts |
| `ArrowRight` / `ArrowLeft` | `lucide-react` | Step progression and back navigation |

### D. System, Comparison & Presentation Controls
| Icon | Import | Usage Context |
| :--- | :--- | :--- |
| `Smartphone` | `lucide-react` | iOS vs. Android device frame switchers |
| `Palette` | `lucide-react` | Theme comparison modal trigger |
| `Layers` | `lucide-react` | Multi-screen simultaneous canvas view |
| `ArrowLeftRight` / `Columns` | `lucide-react` | Side-by-side A/B theme comparison mode |
| `Heart` | `lucide-react` | Favorited theme bookmarking |
| `BarChart3` / `TrendingUp` | `lucide-react` | Retention metrics and competitor benchmarks |
| `Info` / `HelpCircle` / `AlertTriangle` | `lucide-react` | Policy badges, guidance tooltips, deposit warnings |
| `Signal`, `Wifi`, `Battery` | `lucide-react` | Realistic iOS/Android status bar elements |
| `Phone` / `MessageSquare` / `Send` | `lucide-react` | In-app cleaner chat & direct helpline |
| `X` / `XCircle` | `lucide-react` | Modal dismiss & service cancellation options |

---

## 6. Layout & Spacing Metrics

* **Mobile Viewport Frame**: iOS (390px × 844px), Android (400px × 860px)
* **Touch Targets**: All interactive elements maintain a minimum hit area of **44px** on touchscreens.
* **Paddings**:
  - Container screen outer padding: `px-4 pt-3 pb-6` (16px horizontal)
  - Card inner padding: `p-3.5` to `p-4` (14px – 16px)
  - Pill / Chip badges: `px-2.5 py-0.5`
  - Button padding: `py-2.5 px-4` to `py-3 px-4`
* **Shadow Hierarchy**:
  - Primary cards: `shadow-2xs` to `shadow-xs` for soft, physical edge separation without artificial dark glows.
  - Floating Bottom Navigation: `shadow-lg` with `backdrop-blur-md` for legibility over scrolled content.
