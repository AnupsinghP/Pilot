const { getDefaultConfig } = require('expo/metro-config');

const config = getDefaultConfig(__dirname);

// lucide-react-native (and a few other packages) ship a package.json "exports" map
// that Metro's newer package-exports resolution doesn't always resolve correctly,
// causing "Unable to resolve" errors even though the file exists on disk.
// Falling back to the classic main/module/react-native fields avoids that.
config.resolver.unstable_enablePackageExports = false;

module.exports = config;
