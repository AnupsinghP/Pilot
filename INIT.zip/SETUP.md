# PILOTAPP — Project Setup

## Known issue on this machine: npm registry blocked for new packages

This machine's npm is pinned to a corporate Artifactory registry:
```
https://artifactory.wolterskluwer.io/artifactory/api/npm/group-npm/
```
(set in `C:\Users\<you>\.npmrc`, with `always-auth = true`)

**Symptom:** `npm view <pkg>` (metadata) works fine, but `npm pack <pkg>` / `npm install <pkg>`
fails with `404 Not Found` for any package not already cached in this Artifactory instance —
confirmed even for the plain `expo` package itself, not just template packages. A package
that was already cached (`is-array@1.0.1`) installed instantly, confirming the split.

Bypassing with `--registry https://registry.npmjs.org` returns `403 Forbidden` — the
corporate network blocks direct access to the public registry too.

**This is a server-side/IT infrastructure issue**, not fixable via CLI flags. Likely causes:
- The Artifactory `group-npm` remote repo has "fetch missing artifacts from remote" disabled
  or misconfigured for uncached packages.
- A corporate proxy/firewall rule blocking large package downloads specifically.

### Options to resolve
1. **File an IT ticket** — ask them to check the Artifactory npm remote repo config (fetch-through
   for uncached packages) for `group-npm`, or point you to a dedicated `npm-remote` repo key.
2. **Try on a different machine/network** (this is what this file is for) — see steps below.
3. Ask a colleague with working registry access to run `npm install` for this project and hand you
   the resulting `node_modules` folder or an npm cache export.

---

## Setup steps on a machine with working npm access

1. Install prerequisites:
   - [Node.js LTS](https://nodejs.org/) (v18+)
   - **Expo Go** app on your phone (App Store / Google Play) — for live preview, no emulator needed

2. Scaffold the project (creates TypeScript + Expo Router + Tabs template):
   ```powershell
   cd path\to\PILOTAPP
   npx create-expo-app@latest .
   ```
   When prompted **"Choose a template"**, select **"Tabs (TypeScript)"**.

   > If it prompts about an Expo SDK version and a `sdk-5X` tag error occurs (a known transient
   > publishing lag right after a new Expo SDK release), retry after a few minutes, or explicitly
   > pass a template flag: `npx create-expo-app@latest . -t tabs`

3. Install additional dependencies used by this app:
   ```powershell
   npm install zustand @react-native-async-storage/async-storage
   ```

4. Verify it runs:
   ```powershell
   npx expo start
   ```
   Scan the QR code shown in the terminal with **Expo Go** on your phone (same Wi-Fi network as
   your PC). The default template screen should load on your device.

5. Once confirmed working, let the agent know — implementation of the mock UI (screens, theme,
   mock data, navigation) will proceed from there, based on the plan already agreed on.

## Project plan reference
The full feature list, screen list, phased implementation plan, and design decisions
(tech stack, branding/theme system, differentiator features) were already agreed upon
and are tracked separately — no need to re-decide these on the new machine, just get
steps 1-4 above working and report back.
