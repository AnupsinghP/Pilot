# PureNest Services, Menu Options & Workflow Documentation

A comprehensive guide to all user menus, service offerings, pricing structures, and end-to-end operational workflows for **PureNest** — an inspection-grade home cleaning platform built for high-end urban Indian households (Bangalore, Mumbai, NCR).

---

## Table of Contents
1. [Executive Summary & Core Value Proposition](#1-executive-summary--core-value-proposition)
2. [Global Navigation & Menu Options](#2-global-navigation--menu-options)
   - [Desktop / Global Application Header](#desktop--global-application-header)
   - [Design Theme & Evaluation Bar](#design-theme--evaluation-bar)
   - [Mobile In-App Bottom Navigation](#mobile-in-app-bottom-navigation)
3. [Comprehensive Service Catalog](#3-comprehensive-service-catalog)
   - [Core Cleaning Services](#a-core-cleaning-services)
   - [Deep Cleaning Add-Ons (À la Carte Menu)](#b-deep-cleaning-add-ons-à-la-carte-menu)
   - [Recurring Subscription Plans (Cleaning Club)](#c-recurring-subscription-plans-cleaning-club)
4. [Step-by-Step User Workflows](#4-step-by-step-user-workflows)
   - [Workflow 1: Everyday Reset / Standard Home Booking](#workflow-1-everyday-reset--standard-home-booking)
   - [Workflow 2: 100% Deposit-Back Move-Out Guarantee Flow](#workflow-2-100-deposit-back-move-out-guarantee-flow)
   - [Workflow 3: Festive & Seasonal Deep Reset Flow](#workflow-3-festive--seasonal-deep-reset-flow)
   - [Workflow 4: Dedicated Cleaner Subscription Lock-In Flow](#workflow-4-dedicated-cleaner-subscription-lock-in-flow)
   - [Workflow 5: Live Clean Tracking & Remote Photo Inspection](#workflow-5-live-clean-tracking--remote-photo-inspection)
   - [Workflow 6: Pitch Deck & Market Strategy Evaluation](#workflow-6-pitch-deck--market-strategy-evaluation)
5. [Summary Matrix of Rates, Durations & Deliverables](#5-summary-matrix-of-rates-durations--deliverables)

---

## 1. Executive Summary & Core Value Proposition

PureNest addresses the three critical pain points in domestic services across Indian metros:
1. **Uncertain Deposit Returns**: Tenants dread deductions of ₹10,000–₹50,000 by landlords or society managers over hard water stains, dirty chimneys, or balustrades. PureNest provides a **100% Deposit-Back Guarantee** backed by photo proofs and a free 48-hour re-clean promise.
2. **The "Stranger Carousel"**: Traditional apps dispatch random gig workers for each visit. PureNest lets subscribers **lock in the same vetted primary cleaner** for every clean.
3. **Health & Indoor Air Quality**: All cleans include certified plant-based, pet-safe, and child-safe non-toxic kits (no hazardous hydrochloric acids or cheap phenyls).

---

## 2. Global Navigation & Menu Options

The application architecture features a dual-layer interface: a desktop framing environment (for device simulation, multi-screen review, and theme switching) and the native mobile smartphone interface.

### Desktop / Global Application Header

Located at the top of the browser viewport:

| Menu Control | Type | Options / States | Purpose |
| :--- | :--- | :--- | :--- |
| **Brand Identifier** | Logo + Pill | `PureNest`, `Pronto × Snabbit` | Identifies the project and architectural benchmark. |
| **Active Style Pill** | Dynamic Badge | *e.g., Warm Sandstone* | Displays currently active design archetype. |
| **Screen Switcher** | Tab Segment | `Home`, `Move-Out`, `Seasonal`, `Subscription`, `Live Clean` | Direct 1-click jump to any core mobile screen. |
| **Device Simulator** | Segmented Control | `iOS` (390×844), `Android` (400×860), `All Screens` (Multi-view canvas) | Tests responsive ergonomics across Apple and Android flagships. |
| **Pitch Deck** | Action Button | `Pitch Deck` (`research` screen) | Opens competitive market research, unit economics, and aggregator gaps. |

---

### Design Theme & Evaluation Bar

Situated immediately below the main header (`ThemeSelectorBar.tsx`):

| Menu Option | Options | Purpose |
| :--- | :--- | :--- |
| **Theme Selector** | 1. `Warm Sandstone` (Default)<br>2. `Monsoon Minimalist`<br>3. `Festive Marigold`<br>4. `Quiet Luxury` | Switches entire palette, border radiuses, typography, and contrast tokens dynamically. |
| **Split Compare (A/B)** | Toggle Button (`Compare`) | Renders two phones side-by-side to compare visual hierarchy across themes. |
| **Design Studio** | Button (`Design Studio`) | Opens a modal evaluation matrix comparing aesthetics, target audience, and typography pairings. |
| **Bookmark Theme** | Heart Icon | Stores the user's preferred design style in local session memory. |

---

### Mobile In-App Bottom Navigation

Sticky navigation located at the bottom of the device viewport (`BottomNav.tsx`):

| Tab | Icon | Badge / Indicator | Destination Screen | Description |
| :--- | :--- | :--- | :--- | :--- |
| **Explore** | `Sparkles` | — | `home` | Discovery feed, quick room customizer, service tiers, nearby cleaner radar. |
| **Move-Out** | `ShieldCheck` | `Guarantee` (Green Pill) | `moveout` | Tenancy handover, landlord inspection reports, society deposit protection. |
| **Seasonal** | `Leaf` | — | `seasonal` | Quarterly allergen, post-monsoon, and pre-Diwali deep cleaning packages. |
| **Plans** | `CalendarClock`| `-20%` (Savings Pill) | `subscription` | Bi-weekly, weekly, and monthly memberships with cleaner lock-in. |
| **Live Clean** | `Activity` | Pulsing Green Dot | `tracker` | Real-time GPS/job progress, room milestones, before/after photos, chat. |

---

## 3. Comprehensive Service Catalog

### A. Core Cleaning Services

All services are flat-rate, room-customizable, and include non-toxic cleaning agents:

```
+-----------------------------------------------------------------------------------------+
|                                CORE CLEANING PACKAGES                                   |
+----------------------+-----------+----------+-------------------------------------------+
| Service Name         | Base Rate | Duration | Best Suited For                           |
+----------------------+-----------+----------+-------------------------------------------+
| Everyday Reset       | ₹1,499    | 2.5 hrs  | Maintenance cleans, living areas, kitchen |
| Move-Out Deep Clean  | ₹2,999    | 4.5 hrs  | Tenancy end, handover inspection pass     |
| Festive Pre-Season   | ₹2,499    | 3.5 hrs  | Diwali, Navratri, post-monsoon reset      |
| Express 60-Min Rush  | ₹999      | 1.5 hrs  | Emergency arrival, party rescues, speed   |
+----------------------+-----------+----------+-------------------------------------------+
```

#### 1. Everyday Reset (`standard-clean`)
* **Base Price**: ₹1,499 (for 1 BHK / 1 Bath)
* **Duration**: 2.5 hours
* **Scope & Inclusions**:
  - High-touch surface dusting & fixture polish
  - Kitchen countertop scrub, stovetop degreasing & sink sanitization
  - Complete bathroom tile, commode & mirror sanitization with chrome polish
  - High-power floor vacuuming and wet antibacterial mopping
  - Bed linen straightening or full linen replacement upon request
* **Recommended Cadence**: Weekly or Bi-weekly

#### 2. End of Tenancy / Deep Clean (`move-out-deep`)
* **Base Price**: ₹2,999 (for 1 BHK / 1 Bath)
* **Badge**: *Guaranteed Pass*
* **Duration**: 4.5 hours
* **Scope & Inclusions**:
  - Top-to-bottom restoration designed to pass landlord and society checklists
  - Interior kitchen cabinetry, drawers, and under-sink degreasing
  - Deep kitchen chimney filter degreasing and exhaust fan cleanup
  - Full refrigerator & freezer defrost wipe and sanitization (when emptied)
  - Balcony pressure scrubbing and sliding glass track detail
  - Hard water scale removal on glass shower partitions and ceramic tiles
  - Formal signed Landlord Before/After Photo Inspection Report

#### 3. Festive Pre-Season Deep Clean (`seasonal-revive`)
* **Base Price**: ₹2,499 (for 1 BHK / 1 Bath)
* **Badge**: *Festive Ready*
* **Duration**: 3.5 hours
* **Scope & Inclusions**:
  - Intensive deep clean targeting fine-particulate dust and post-monsoon dampness
  - Sofa upholstery, carpet, and heavy drape dry vacuum extraction
  - Window glass polishing, sliding tracks scrub, and mosquito mesh clearing
  - High dusting of ceiling fan blades, cornice moldings, and AC vent louvers
  - Under-bed and heavy furniture sweep and sanitization
  - Organic botanical citrus & lavender essential oil room misting

#### 4. Express 60-Min Rush (`pronto-express`)
* **Base Price**: ₹999
* **Badge**: *Fast Dispatch*
* **Duration**: 1.5 hours
* **Scope & Inclusions**:
  - Same-day cleaner dispatched within 45–60 minutes
  - Priority speed clean for unexpected guests, house parties, or quick rescues
  - Surface declutter, trash haul, kitchen slab wipe, and bathroom refresh
  - Real-time GPS cleaner location tracker

---

### B. Deep Cleaning Add-Ons (À la Carte Menu)

Users can customize any booking with specialized micro-services:

| Add-On Service | Rate | Est. Time | Specialized Equipment / Methodology |
| :--- | :--- | :--- | :--- |
| **Deep Kitchen Chimney Degreasing** | +₹699 | 40 mins | Filter detachment, baffle soaking in organic solvent, motor hood scrub. |
| **Interior Refrigerator Deep Clean** | +₹499 | 35 mins | Removable bin soak, antibacterial sanitization, rubber gasket mildew scrub. |
| **Interior Windows & Tracks (Up to 8)** | +₹599 | 45 mins | Streak-free squeegee, track vacuuming, mosquito mesh dust extraction. |
| **Balcony Washing & Scrubbing** | +₹399 | 30 mins | Floor pressure scrub, hard water tile wash, glass railing wipe. |
| **Inside All Kitchen Cabinets** | +₹499 | 40 mins | Empty shelf wipe, spice bin declutter scrub, drawer corner vacuum. |
| **Wall Scuff & Baseboard Eraser** | +₹299 | 25 mins | Non-abrasive melamine eraser along skirting boards and entryways. |
| **Sofa & Carpet Mechanical Shampooing**| +₹899 | 30 mins | Mechanical foam agitation and high-suction water extraction. |
| **Organic Botanical Essential Mist** | +₹199 | 10 mins | Eucalyptus & lavender cold-mist diffuser purification. |
| **Furnished Property Surcharge** | +₹499 | 45 mins | Intensive detailing around upholstery, furniture crevices, and decor. |

---

### C. Recurring Subscription Plans (Cleaning Club)

Subscriptions offer recurring savings, dedicated personnel, and automated scheduling:

```
+----------------------------------------------------------------------------------------------------+
|                                    CLEANING CLUB MEMBERSHIPS                                       |
+-------------------+----------+----------------+----------------------------------------------------+
| Plan Name         | Discount | Price / Clean  | Key Member Perks                                   |
+-------------------+----------+----------------+----------------------------------------------------+
| Bi-Weekly Flow    | -20%     | ₹1,199 (₹1499) | Dedicated pro, free festive clean/6mo, 1-tap pause |
| Weekly Pristine   | -25%     | ₹1,124 (₹1499) | Maximum savings, free quarterly balcony, VIP desk  |
| Monthly Deep      | -12%     | ₹1,319 (₹1499) | Auto-pilot scheduling, unused cleans rollover      |
+-------------------+----------+----------------+----------------------------------------------------+
```

#### Flexibility & Trust Guarantees:
* **Dedicated Primary Cleaner Lock-In**: Subscribers choose their certified professional (`Priya Sharma`, `Rajesh Kumar`, or `Sunita Desai`). The pro is permanently assigned to the home.
* **1-Tap Travel Pause**: Users can freeze visits when out of town without fees or forfeiture.
* **Rollover Cleans**: Unused visits automatically roll forward to subsequent months.
* **Society Gate Pre-Approval**: Seamless entry pass generation for residential security desks (e.g., MyGate, NoBrokerHood).

---

## 4. Step-by-Step User Workflows

### Workflow 1: Everyday Reset / Standard Home Booking

```
[Home Screen] ──> [Room Customizer] ──> [Continue] ──> [Booking Screen] ──> [Live Tracker]
```

1. **Initiation**: User opens the **Explore** tab (`HomeScreen`). The top bar displays their saved address (`Tower 4, DLF Camellias, Apt 4B`).
2. **Service Selection**: User taps **Everyday Reset** (₹1,499) or another service card.
3. **Room Customizer**:
   - User adjusts bedrooms (`-` / `+`, 1 to 6 BHK) and bathrooms (1 to 5).
   - Price updates dynamically (₹300 per extra bedroom, ₹350 per extra bathroom).
4. **Continue**: User taps `Continue with Everyday Reset`.
5. **Reservation Screen (`BookingFlowScreen`)**:
   - **Arrival Window**: User chooses between *Today (Express, 60m)*, *Tomorrow (9 AM - 12 PM)*, *This Saturday*, etc.
   - **Access Method**: User selects between *Lockbox / Keypad*, *Front Desk / Guard*, or *I'll be Home*. If Lockbox is selected, passcode and notes fields appear.
   - **Eco Kit Verification**: Confirms certified plant-based kit inclusion.
6. **Confirmation**: Tapping `Confirm & Dispatch Cleaner` triggers a reservation spinner, automatically navigating to the **Live Tracker**.

---

### Workflow 2: 100% Deposit-Back Move-Out Guarantee Flow

```
[Move-Out Tab] ──> [Toggle Guarantee] ──> [Property State] ──> [Add-Ons] ──> [Booking]
```

1. **Initiation**: User navigates to the **Move-Out** tab (`MoveOutScreen`) via the bottom bar or Home banner.
2. **Deposit Guarantee Configuration**:
   - Green badge displays `100% Deposit-Back Guarantee`.
   - User toggles the **Landlord Inspection Pass** switch.
   - If enabled, an input field prompts for the **Property Manager / Landlord Email** to automatically send the post-clean signed PDF.
3. **Property State Selection**:
   - User toggles between `Empty / Unfurnished` or `Furnished (+ ₹499)`.
4. **Inspection Add-Ons**:
   - User checks off items commonly inspected by owners (e.g., *Deep Chimney Degreasing*, *Interior Refrigerator*, *Balcony Wash*).
   - Each selected add-on recalculates the guaranteed total quote in the sticky bottom bar.
5. **Checkout**: User clicks `Schedule Move-Out`, transferring the custom configuration and landlord email to `BookingFlowScreen`.
6. **Safety Net**: If any issue is reported by the owner or society within 48 hours, a contractor returns free of charge.

---

### Workflow 3: Festive & Seasonal Deep Reset Flow

```
[Seasonal Tab] ──> [Select Season] ──> [Botanical Mist] ──> [Cadence] ──> [Booking]
```

1. **Initiation**: User taps the **Seasonal** tab (`SeasonalScreen`).
2. **Season Selector**:
   - **Spring & Post-Monsoon Allergen Flush** (₹2,499): HEPA vacuuming, mattress UV treatment, AC louvers, window tracks.
   - **Festive Pre-Diwali Deep Reset** (₹2,799): Furniture sweep, kitchen degreasing, baseboards, puja corner care.
   - **Pre-Hosting Entertainment Prep** (₹2,299): Glassware polish, chandelier dusting, chrome detailing, guest suite prep.
3. **Botanical Aromatherapy**:
   - User toggles **Organic Botanical Essential Mist (+ ₹199)** for lavender and eucalyptus cold-diffusion.
4. **Smart Cadence Review**:
   - Highlights the auto-pilot quarterly plan option to save an additional 15%.
5. **Checkout**: Taps `Book Seasonal Reset`, pre-filling the booking flow.

---

### Workflow 4: Dedicated Cleaner Subscription Lock-In Flow

```
[Plans Tab] ──> [Select Frequency] ──> [Lock Primary Cleaner] ──> [Activate Plan]
```

1. **Initiation**: User taps the **Plans** tab (`SubscriptionScreen`).
2. **Frequency Choice**:
   - User compares *Bi-Weekly Flow* (-20%, ₹1,199/clean), *Weekly Pristine* (-25%, ₹1,124/clean), or *Monthly Deep Reset* (-12%, ₹1,319/clean).
3. **Cleaner Lock-In**:
   - Screen displays the assigned primary cleaner profile (e.g., *Priya Sharma, 4.98 Rating, 620 cleans*).
   - User can tap `Switch` to cycle through available top-rated professionals in the zone.
4. **Terms Review**: Confirms *1-Tap Pause*, *Rollover Cleans*, and *Free Periodic Perks*.
5. **Activation**: User taps `Activate Plan (₹1,199/clean)` to set up recurring billing without long-term contracts.

---

### Workflow 5: Live Clean Tracking & Remote Photo Inspection

```
[Live Clean Tab] ──> [Progress Bar] ──> [Room Milestones] ──> [Photo Proofs] ──> [PDF Pass]
```

1. **Initiation**: Accessible via the **Live Clean** tab or immediately after booking confirmation.
2. **Job Dashboard**:
   - Displays cleaner photo, name, star rating, phone button, and live status (*Clean In Progress • 65m remaining*).
   - Real-time **Progress Bar** reflects total task completion (e.g., `50% - 3/6 tasks`).
3. **Room-by-Room Inspection Milestones**:
   - Tasks are grouped by room (*Kitchen*, *Master Bathroom*, *Living Room*, *Bedrooms*).
   - Status indicators change from `Pending` (grey clock) to `In Progress` (pulsing amber) to `Completed` (green check + `Verified` badge).
   - Cleaner notes are displayed in real-time (e.g., *"Micro-fiber scrub applied. Chrome fittings streak-free."*).
4. **Photo Proof Verification**:
   - High-resolution thumbnails appear next to completed milestones.
   - Tapping any photo opens the full inspection modal with geo-tagging and timestamp details.
5. **Cleaner Micro-Chat**:
   - Direct two-way messaging window allows instant instructions (e.g., *"Please detail the master shower glass"*).
6. **Pass PDF Generation**:
   - User taps `Pass PDF` in the top right to download a certified inspection report for the landlord or tenant archive.

---

### Workflow 6: Pitch Deck & Market Strategy Evaluation

```
[Header Button: Pitch Deck] ──> [Market Summary] ──> [Competitor Matrix] ──> [Unit Economics]
```

1. **Initiation**: Click the `Pitch Deck` button in the top header or Home screen.
2. **Market Analysis**:
   - Examines why traditional aggregators fail high-end households (inconsistent gig quality, absence of deposit liability, no dedicated personnel).
3. **Competitive Matrix**:
   - Compares PureNest against standard platforms across 5 dimensions: Handover Guarantees, Dedicated Staff, Transparent Pricing, Real-time Photo Inspection, and Non-toxic Kits.
4. **Unit Economics Review**:
   - CAC payback (1.8 months), 90-day subscription retention (78%), and conversion rate from Move-Out to Bi-Weekly subscription (31%).

---

## 5. Summary Matrix of Rates, Durations & Deliverables

| Item Name | Category | Flat Rate | Time | Key Deliverable |
| :--- | :--- | :--- | :--- | :--- |
| **Everyday Reset** | Core Service | ₹1,499 | 2.5 hrs | Full maintenance dust, scrub, sanitize & floor mop |
| **End of Tenancy Deep Clean** | Core Service | ₹2,999 | 4.5 hrs | 100% deposit pass with signed before/after photo report |
| **Festive Pre-Season Clean** | Core Service | ₹2,499 | 3.5 hrs | Deep dust extraction, AC louvers, sofa dry vacuum & mist |
| **Express 60-Min Rush** | Core Service | ₹999 | 1.5 hrs | Fast turnaround arrival within 45–60 mins |
| **Chimney & Exhaust Degrease**| Add-On | +₹699 | 40 mins | Heavy baffle filter soak and motor hood grease removal |
| **Interior Fridge Sanitization**| Add-On | +₹499 | 35 mins | Shelves washed, gasket mildew scrub & odor neutralization |
| **Window Tracks & Mosquito Mesh**| Add-On | +₹599 | 45 mins | Streak-free squeegee & track vacuuming (up to 8 windows) |
| **Balcony Wash & Railings** | Add-On | +₹399 | 30 mins | Floor tile scrub and glass railing streak-free polish |
| **Inside All Kitchen Cabinets**| Add-On | +₹499 | 40 mins | Interior shelf wipe & spice bin declutter scrub |
| **Wall Scuff Eraser** | Add-On | +₹299 | 25 mins | Skirting board and wall scuff spot removal |
| **Sofa & Carpet Shampooing** | Add-On | +₹899 | 30 mins | Mechanical foam agitation & wet vacuum extraction |
| **Botanical Essential Mist** | Add-On | +₹199 | 10 mins | Lavender & eucalyptus air-purifying room mist |
| **Furnished Property Surcharge**| Add-On | +₹499 | 45 mins | Intensive detailing around furniture crevices |
| **Bi-Weekly Subscription** | Membership | ₹1,199/clean | 2.5 hrs | Save 20%, dedicated cleaner locked in, 1-tap pause |
| **Weekly Subscription** | Membership | ₹1,124/clean | 2.5 hrs | Save 25%, dedicated cleaner, quarterly free perks |
| **Monthly Subscription** | Membership | ₹1,319/clean | 2.5 hrs | Save 12%, rollover unused cleans, auto-pilot cadence |

---

*Document generated for PureNest Mobile Application (`b2d9d701-e1eb-4c9d-b936-4733b5c40cd3`).*
