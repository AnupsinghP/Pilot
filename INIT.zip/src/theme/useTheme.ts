import { useBrandStore } from '@/src/store/brandStore';
import { fontFamily } from './fonts';
import { DEFAULT_PALETTE_ID, palettes } from './palettes';
import { shadow, spacing, typography } from './tokens';

export function useTheme() {
  const paletteId = useBrandStore((s) => s.paletteId);
  const palette = palettes[paletteId] ?? palettes[DEFAULT_PALETTE_ID];

  return {
    paletteId: palette.id,
    themeName: palette.name,
    subtitle: palette.subtitle,
    tagline: palette.tagline,
    colors: palette.colors,
    tints: palette.tints,
    hero: palette.hero,
    spacing,
    radii: palette.radii,
    typography,
    shadow,
    fonts: fontFamily,
  };
}


export type Theme = ReturnType<typeof useTheme>;
