// PureNest design system themes — see DESIGN_SYSTEM.md for full source spec.
export type PaletteId = 'warmSandstone' | 'monsoonMinimalist' | 'festiveMarigold' | 'quietLuxury';

export interface PaletteColors {
  primary: string;
  primaryMuted: string;
  secondary: string;
  accent: string;
  background: string;
  surface: string;
  surfaceSubtle: string;
  surfaceMuted: string;
  border: string;
  borderSubtle: string;
  textPrimary: string;
  textSecondary: string;
  textMuted: string;
  textOnPrimary: string;
  success: string;
  warning: string;
  danger: string;
}

export interface PaletteRadii {
  sm: number;
  md: number;
  lg: number;
  xl: number;
  pill: number;
}

export interface Palette {
  id: PaletteId;
  name: string;
  subtitle: string;
  tagline: string;
  colors: PaletteColors;
  /** Rotating pastel backgrounds used for category icon chips. */
  tints: string[];
  /** Dark, moody hero-card colors (contrast block on light backgrounds). */
  hero: { background: string; text: string; textMuted: string };
  radii: PaletteRadii;
}

export const palettes: Record<PaletteId, Palette> = {
  warmSandstone: {
    id: 'warmSandstone',
    name: 'Warm Sandstone',
    subtitle: 'Jaipur Terracotta & Organic Linen',
    tagline: 'Mindful, calming, tactile warmth',
    colors: {
      primary: '#292524',
      primaryMuted: '#EFECE6',
      secondary: '#57534E',
      accent: '#059669',
      background: '#FFFFFE',
      surface: '#F7F5F1',
      surfaceSubtle: '#F2EFE9',
      surfaceMuted: '#EAE5DC',
      border: '#E4DED4',
      borderSubtle: '#EDE8E0',
      textPrimary: '#292524',
      textSecondary: '#57534E',
      textMuted: '#78716C',
      textOnPrimary: '#FFFFFF',
      success: '#047857',
      warning: '#92400E',
      danger: '#B4685A',
    },
    tints: ['#EFECE6', '#F2EFE9', '#EAE5DC', '#E4DED4'],
    hero: { background: '#292524', text: '#FFFFFF', textMuted: 'rgba(255,255,255,0.72)' },
    radii: { sm: 8, md: 12, lg: 16, xl: 24, pill: 999 },
  },
  monsoonMinimalist: {
    id: 'monsoonMinimalist',
    name: 'Monsoon Minimalist',
    subtitle: 'Deep Teal & Monsoon Cloud',
    tagline: 'Crisp, modern, authoritative, lightning-fast',
    colors: {
      primary: '#0F172A',
      primaryMuted: '#E0F2FE',
      secondary: '#0F766E',
      accent: '#0284C7',
      background: '#FFFFFE',
      surface: '#F5F7F9',
      surfaceSubtle: '#F1F5F9',
      surfaceMuted: '#E2E8F0',
      border: '#CBD5E1',
      borderSubtle: '#E2E8F0',
      textPrimary: '#0F172A',
      textSecondary: '#334155',
      textMuted: '#64748B',
      textOnPrimary: '#FFFFFF',
      success: '#0D9488',
      warning: '#0284C7',
      danger: '#B3433D',
    },
    tints: ['#E0F2FE', '#F1F5F9', '#E2E8F0', '#DBEAFE'],
    hero: { background: '#0F172A', text: '#FFFFFF', textMuted: 'rgba(255,255,255,0.72)' },
    radii: { sm: 6, md: 8, lg: 12, xl: 20, pill: 999 },
  },
  festiveMarigold: {
    id: 'festiveMarigold',
    name: 'Festive Marigold',
    subtitle: 'Warm Turmeric & Celebratory Glow',
    tagline: 'Joyful, culturally resonant, warm, auspicious',
    colors: {
      primary: '#A63A27',
      primaryMuted: '#FADBD5',
      secondary: '#D97706',
      accent: '#059669',
      background: '#FFFFFE',
      surface: '#FAF4EA',
      surfaceSubtle: '#F5F0E6',
      surfaceMuted: '#EBE2CF',
      border: '#E0D5BC',
      borderSubtle: '#EBE2CF',
      textPrimary: '#4A2C11',
      textSecondary: '#6E421A',
      textMuted: '#9A7045',
      textOnPrimary: '#FFFFFF',
      success: '#047857',
      warning: '#D97706',
      danger: '#A63A27',
    },
    tints: ['#FADBD5', '#F5F0E6', '#EBE2CF', '#FDE7C7'],
    hero: { background: '#A63A27', text: '#FFFFFF', textMuted: 'rgba(255,255,255,0.78)' },
    radii: { sm: 10, md: 16, lg: 16, xl: 24, pill: 999 },
  },
  quietLuxury: {
    id: 'quietLuxury',
    name: 'Quiet Luxury',
    subtitle: 'Onyx & South Mumbai Elegance',
    tagline: '5-star white-glove hotel standard',
    colors: {
      primary: '#1A1815',
      primaryMuted: '#F4ECE0',
      secondary: '#9A7332',
      accent: '#C5A880',
      background: '#FFFFFE',
      surface: '#F6F3EE',
      surfaceSubtle: '#F3EFE9',
      surfaceMuted: '#E6DFD3',
      border: '#D8CFBF',
      borderSubtle: '#E7E0D3',
      textPrimary: '#1A1815',
      textSecondary: '#4A443D',
      textMuted: '#7D756A',
      textOnPrimary: '#FFFFFF',
      success: '#065F46',
      warning: '#9A7332',
      danger: '#8A3B32',
    },
    tints: ['#F4ECE0', '#F3EFE9', '#E6DFD3', '#EFE4D2'],
    hero: { background: '#1A1815', text: '#FFFFFF', textMuted: 'rgba(255,255,255,0.7)' },
    radii: { sm: 6, md: 8, lg: 12, xl: 20, pill: 999 },
  },
};

export const DEFAULT_PALETTE_ID: PaletteId = 'warmSandstone';

export const paletteList = Object.values(palettes);

