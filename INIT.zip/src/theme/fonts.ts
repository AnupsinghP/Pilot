// Font families loaded via @expo-google-fonts packages in app/_layout.tsx.
export const fontFamily = {
  headingRegular: 'PlayfairDisplay_400Regular',
  headingItalic: 'PlayfairDisplay_400Regular_Italic',
  headingMedium: 'PlayfairDisplay_500Medium',
  headingSemiBold: 'PlayfairDisplay_600SemiBold',
  bodyLight: 'PlusJakartaSans_300Light',
  bodyRegular: 'PlusJakartaSans_400Regular',
  bodyMedium: 'PlusJakartaSans_500Medium',
  bodySemiBold: 'PlusJakartaSans_600SemiBold',
  bodyBold: 'PlusJakartaSans_700Bold',
};
