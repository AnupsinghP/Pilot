import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { getAddOnById } from '@/src/data/addOns';
import { AccessMethod, getArrivalSlotById } from '@/src/data/arrivalSlots';
import { getSeasonalPlanById } from '@/src/data/seasonalPlans';
import { computeRoomPrice, getServiceById } from '@/src/data/services';
import { fetchProfessionalForService } from '@/src/services/professionalRepository';

export type BookingMode = 'instant' | 'scheduled';
export type BookingStatus = 'upcoming' | 'in_progress' | 'completed' | 'cancelled';
export type PropertyState = 'empty' | 'furnished';

export interface Booking {
  id: string;
  serviceId: string;
  professionalId: string;
  mode: BookingMode;
  bedrooms?: number;
  bathrooms?: number;
  addOnIds: string[];
  seasonVariantId?: string;
  propertyState?: PropertyState;
  landlordEmail?: string;
  arrivalSlotId?: string;
  accessMethod?: AccessMethod;
  lockboxCode?: string;
  entryNotes?: string;
  addressId: string;
  paymentMethodId: string;
  otp: string;
  status: BookingStatus;
  createdAt: number;
  totalPriceInr: number;
  rating?: number;
  review?: string;
}

interface Draft {
  serviceId?: string;
  mode: BookingMode;
  bedrooms?: number;
  bathrooms?: number;
  addOnIds: string[];
  seasonVariantId?: string;
  propertyState?: PropertyState;
  landlordEmail?: string;
  arrivalSlotId?: string;
  accessMethod?: AccessMethod;
  lockboxCode?: string;
  entryNotes?: string;
  addressId?: string;
  paymentMethodId?: string;
}

interface BookingState {
  draft: Draft;
  bookings: Booking[];
  setDraft: (partial: Partial<Draft>) => void;
  resetDraft: () => void;
  confirmBooking: () => Promise<string>;
  updateStatus: (id: string, status: BookingStatus) => void;
  addReview: (id: string, rating: number, review: string) => void;
  getBooking: (id: string) => Booking | undefined;
}

const initialDraft: Draft = { mode: 'instant', addOnIds: [] };

function generateOtp(): string {
  return String(Math.floor(1000 + Math.random() * 9000));
}

/** Base service/room price plus any selected add-ons (handles Move-Out & Seasonal variants). */
export function computeDraftTotal(draft: Draft): number {
  const service = draft.serviceId ? getServiceById(draft.serviceId) : undefined;
  if (!service) return 0;

  if (service.id === 'seasonal-revive' && draft.seasonVariantId) {
    const plan = getSeasonalPlanById(draft.seasonVariantId);
    const base = plan?.priceInr ?? service.priceInr;
    const addOnsTotal = draft.addOnIds.reduce((sum, id) => sum + (getAddOnById(id)?.priceInr ?? 0), 0);
    return base + addOnsTotal;
  }

  if (service.id === 'move-out-deep') {
    const furnishedSurcharge = draft.propertyState === 'furnished' ? 499 : 0;
    const addOnsTotal = draft.addOnIds.reduce((sum, id) => sum + (getAddOnById(id)?.priceInr ?? 0), 0);
    return service.priceInr + furnishedSurcharge + addOnsTotal;
  }

  const base =
    service.roomCustomizable && draft.bedrooms && draft.bathrooms
      ? computeRoomPrice(service.priceInr, draft.bedrooms, draft.bathrooms)
      : service.priceInr;
  const addOnsTotal = draft.addOnIds.reduce((sum, id) => sum + (getAddOnById(id)?.priceInr ?? 0), 0);
  return base + addOnsTotal;
}

export const useBookingStore = create<BookingState>()(
  persist(
    (set, get) => ({
      draft: initialDraft,
      bookings: [],
      setDraft: (partial) => set((state) => ({ draft: { ...state.draft, ...partial } })),
      resetDraft: () => set({ draft: initialDraft }),
      confirmBooking: async () => {
        const { draft } = get();
        if (!draft.serviceId || !draft.addressId || !draft.paymentMethodId) {
          throw new Error('Incomplete booking draft');
        }
        const professional = await fetchProfessionalForService(draft.serviceId);
        const booking: Booking = {
          id: `bk-${Date.now()}`,
          serviceId: draft.serviceId,
          professionalId: professional.id,
          mode: draft.mode,
          bedrooms: draft.bedrooms,
          bathrooms: draft.bathrooms,
          addOnIds: draft.addOnIds,
          seasonVariantId: draft.seasonVariantId,
          propertyState: draft.propertyState,
          landlordEmail: draft.landlordEmail,
          arrivalSlotId: draft.arrivalSlotId,
          accessMethod: draft.accessMethod,
          lockboxCode: draft.lockboxCode,
          entryNotes: draft.entryNotes,
          addressId: draft.addressId,
          paymentMethodId: draft.paymentMethodId,
          otp: generateOtp(),
          status: 'upcoming',
          createdAt: Date.now(),
          totalPriceInr: computeDraftTotal(draft),
        };
        set((state) => ({ bookings: [booking, ...state.bookings] }));
        return booking.id;
      },
      updateStatus: (id, status) =>
        set((state) => ({
          bookings: state.bookings.map((b) => (b.id === id ? { ...b, status } : b)),
        })),
      addReview: (id, rating, review) =>
        set((state) => ({
          bookings: state.bookings.map((b) => (b.id === id ? { ...b, rating, review } : b)),
        })),
      getBooking: (id) => get().bookings.find((b) => b.id === id),
    }),
    {
      name: 'booking-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
