import AsyncStorage from '@react-native-async-storage/async-storage';
import { create } from 'zustand';
import { createJSONStorage, persist } from 'zustand/middleware';
import { DEFAULT_PALETTE_ID, PaletteId } from '@/src/theme/palettes';

interface BrandState {
  appName: string;
  paletteId: PaletteId;
  setAppName: (name: string) => void;
  setPaletteId: (id: PaletteId) => void;
}

export const useBrandStore = create<BrandState>()(
  persist(
    (set) => ({
      appName: 'PureNest',
      paletteId: DEFAULT_PALETTE_ID,
      setAppName: (name) => set({ appName: name }),
      setPaletteId: (id) => set({ paletteId: id }),
    }),
    {
      name: 'brand-storage',
      storage: createJSONStorage(() => AsyncStorage),
    }
  )
);
