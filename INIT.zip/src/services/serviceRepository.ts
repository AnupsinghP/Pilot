import { getServiceById, Service } from '@/src/data/services';

// Thin repository layer: mock implementations now, swap internals for real
// API calls later without changing any screen/component code.

export async function fetchService(id: string): Promise<Service | undefined> {
  return getServiceById(id);
}

