import { getProfessionalById, Professional, professionals } from '@/src/data/professionals';

export async function fetchProfessionals(): Promise<Professional[]> {
  return professionals;
}

export async function fetchProfessional(id: string): Promise<Professional | undefined> {
  return getProfessionalById(id);
}

/** Deterministic-ish pick so the same service tends to show the same pro during a demo. */
export async function fetchProfessionalForService(serviceId: string): Promise<Professional> {
  const index = serviceId.length % professionals.length;
  return professionals[index];
}
