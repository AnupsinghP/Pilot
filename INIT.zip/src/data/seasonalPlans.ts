// Seasonal Deep Reset variants — see "Services and workflow.md" Workflow 3.
export interface SeasonalPlan {
  id: string;
  name: string;
  badge: string;
  priceInr: number;
  description: string;
  includes: string[];
}

export const seasonalPlans: SeasonalPlan[] = [
  {
    id: 'spring',
    name: 'Spring & Post-Monsoon Allergen Flush',
    badge: 'POPULAR NOW',
    priceInr: 2499,
    description: 'HEPA extraction, window sills, track detailing & mattress sanitization',
    includes: [
      'Interior window glass, tracks & frame scrub',
      'HEPA vacuuming of sofa cushions, rugs & curtains',
      'Mattress UV sanitization & dust mite extraction',
      'Ceiling fan blades & AC vent intake wash',
      'Organic botanical citrus/lavender room misting',
    ],
  },
  {
    id: 'autumn',
    name: 'Festive Pre-Diwali Deep Reset',
    badge: 'FESTIVE SPECIAL',
    priceInr: 2799,
    description: 'Under-furniture dust clearance, puja corner detailing & kitchen degrease',
    includes: [
      'Deep under-bed and heavy furniture sweep',
      'Baseboard erasure & radiator/heater sanitization',
      'Kitchen pantry & spice rack shelf sanitization',
      'Hardwood deep conditioner & buffing',
    ],
  },
  {
    id: 'holiday',
    name: 'Pre-Hosting Entertainment Prep',
    badge: 'HOSTING READY',
    priceInr: 2299,
    description: 'High-shine glassware polish, kitchen degrease & guest suite prep',
    includes: [
      'Guest bedroom & ensuite hotel-standard prep',
      'Dining room chandelier & fixture dusting',
      'High-polish chrome, mirrors & stainless appliances',
      'Entryway & coat closet declutter wipe',
    ],
  },
];

export function getSeasonalPlanById(id: string): SeasonalPlan | undefined {
  return seasonalPlans.find((p) => p.id === id);
}
