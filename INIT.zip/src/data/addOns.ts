// À la carte add-ons that customize any booking — see "Services and workflow.md".
export interface AddOn {
  id: string;
  name: string;
  priceInr: number;
  durationMins: number;
  description: string;
}

export const addOns: AddOn[] = [
  {
    id: 'addon-chimney',
    name: 'Deep Kitchen Chimney Degreasing',
    priceInr: 699,
    durationMins: 40,
    description: 'Filter detachment, baffle soaking in organic solvent, motor hood scrub.',
  },
  {
    id: 'addon-fridge',
    name: 'Interior Refrigerator Deep Clean',
    priceInr: 499,
    durationMins: 35,
    description: 'Removable bin soak, antibacterial sanitization, rubber gasket mildew scrub.',
  },
  {
    id: 'addon-windows',
    name: 'Interior Windows & Tracks (Up to 8)',
    priceInr: 599,
    durationMins: 45,
    description: 'Streak-free squeegee, track vacuuming, mosquito mesh dust extraction.',
  },
  {
    id: 'addon-balcony',
    name: 'Balcony Washing & Scrubbing',
    priceInr: 399,
    durationMins: 30,
    description: 'Floor pressure scrub, hard water tile wash, glass railing wipe.',
  },
  {
    id: 'addon-cabinets',
    name: 'Inside All Kitchen Cabinets',
    priceInr: 499,
    durationMins: 40,
    description: 'Empty shelf wipe, spice bin declutter scrub, drawer corner vacuum.',
  },
  {
    id: 'addon-walls',
    name: 'Wall Scuff & Baseboard Eraser',
    priceInr: 299,
    durationMins: 25,
    description: 'Non-abrasive melamine eraser along skirting boards and entryways.',
  },
  {
    id: 'addon-sofa',
    name: 'Sofa & Carpet Mechanical Shampooing',
    priceInr: 899,
    durationMins: 30,
    description: 'Mechanical foam agitation and high-suction water extraction.',
  },
  {
    id: 'addon-mist',
    name: 'Organic Botanical Essential Mist',
    priceInr: 199,
    durationMins: 10,
    description: 'Eucalyptus & lavender cold-mist diffuser purification.',
  },
  {
    id: 'addon-furnished',
    name: 'Furnished Property Surcharge',
    priceInr: 499,
    durationMins: 45,
    description: 'Intensive detailing around upholstery, furniture crevices, and decor.',
  },
];

export function getAddOnById(id: string): AddOn | undefined {
  return addOns.find((a) => a.id === id);
}
