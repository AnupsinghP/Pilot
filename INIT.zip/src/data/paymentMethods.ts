export interface PaymentMethod {
  id: string;
  label: string;
  icon: 'Smartphone' | 'CreditCard' | 'Wallet' | 'Banknote';
}

export const paymentMethods: PaymentMethod[] = [
  { id: 'upi', label: 'UPI', icon: 'Smartphone' },
  { id: 'card', label: 'Credit / Debit Card', icon: 'CreditCard' },
  { id: 'wallet', label: 'Wallet', icon: 'Wallet' },
  { id: 'cash', label: 'Cash on Service', icon: 'Banknote' },
];

export function getPaymentMethodById(id: string): PaymentMethod | undefined {
  return paymentMethods.find((p) => p.id === id);
}
