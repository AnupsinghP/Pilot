export interface Professional {
  id: string;
  name: string;
  avatarUrl: string;
  rating: number;
  completedJobs: number;
  yearsExperience: number;
  bio: string;
  idVerified: boolean;
  backgroundCheckPassed: boolean;
  trainingCertified: boolean;
  languages: string[];
}

export const professionals: Professional[] = [
  {
    id: 'pro-1',
    name: 'Priya Sharma',
    avatarUrl: 'https://randomuser.me/api/portraits/women/68.jpg',
    rating: 4.98,
    completedJobs: 620,
    yearsExperience: 6,
    bio: 'End of Tenancy & Detail Perfectionist. Loved for spotless landlord inspection passes.',
    idVerified: true,
    backgroundCheckPassed: true,
    trainingCertified: true,
    languages: ['Hindi', 'Marathi', 'English'],
  },
  {
    id: 'pro-2',
    name: 'Rajesh Kumar',
    avatarUrl: 'https://randomuser.me/api/portraits/men/45.jpg',
    rating: 4.95,
    completedJobs: 215,
    yearsExperience: 5,
    bio: 'Speed & deep kitchen degreasing specialist, great for express rush bookings.',
    idVerified: true,
    backgroundCheckPassed: true,
    trainingCertified: true,
    languages: ['Hindi', 'English'],
  },
  {
    id: 'pro-3',
    name: 'Sunita Desai',
    avatarUrl: 'https://randomuser.me/api/portraits/women/44.jpg',
    rating: 4.9,
    completedJobs: 2010,
    yearsExperience: 7,
    bio: 'Loves sofa & carpet shampooing, very detail oriented.',
    idVerified: true,
    backgroundCheckPassed: true,
    trainingCertified: true,
    languages: ['Hindi', 'English'],
  },
  {
    id: 'pro-3b',
    name: 'Rekha Nagraj',
    avatarUrl: 'https://randomuser.me/api/portraits/women/21.jpg',
    rating: 4.7,
    completedJobs: 860,
    yearsExperience: 3,
    bio: 'Friendly and efficient with daily house-help tasks.',
    idVerified: true,
    backgroundCheckPassed: true,
    trainingCertified: false,
    languages: ['Kannada', 'Hindi'],
  },
  {
    id: 'pro-4',
    name: 'Anil Kumar',
    avatarUrl: 'https://randomuser.me/api/portraits/men/32.jpg',
    rating: 4.6,
    completedJobs: 540,
    yearsExperience: 2,
    bio: 'Trained pest-control technician, careful with pets & kids around.',
    idVerified: true,
    backgroundCheckPassed: true,
    trainingCertified: true,
    languages: ['Hindi', 'English'],
  },
  {
    id: 'pro-5',
    name: 'Meena Sharma',
    avatarUrl: 'https://randomuser.me/api/portraits/women/56.jpg',
    rating: 4.9,
    completedJobs: 1680,
    yearsExperience: 6,
    bio: 'Move-in/move-out specialist, very thorough and punctual.',
    idVerified: true,
    backgroundCheckPassed: true,
    trainingCertified: true,
    languages: ['Hindi', 'Marathi'],
  },
  {
    id: 'pro-6',
    name: 'Pooja Yadav',
    avatarUrl: 'https://randomuser.me/api/portraits/women/12.jpg',
    rating: 4.75,
    completedJobs: 990,
    yearsExperience: 4,
    bio: 'Great with quick top-up cleans and last-minute bookings.',
    idVerified: true,
    backgroundCheckPassed: true,
    trainingCertified: true,
    languages: ['Hindi', 'English'],
  },
];

export function getProfessionalById(id: string): Professional | undefined {
  return professionals.find((p) => p.id === id);
}
