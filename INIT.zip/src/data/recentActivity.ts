// Mock "recently booked" history — stands in for real order history until a backend exists.
export const recentServiceIds: string[] = ['standard-clean', 'pronto-express'];
