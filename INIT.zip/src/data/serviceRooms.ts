// Room-by-room inclusion breakdown for the "Room-by-room tabs" design concept
// (design-previews/service-concepts.html, concept 03). Keyed by Service.id.
export interface ServiceRoom {
  id: string;
  /** Full display name, e.g. 'Living spaces'. */
  name: string;
  /** Short tab label, e.g. 'Living'. */
  tab: string;
  /** One-line summary, e.g. 'Dust & polish'. */
  short: string;
  /** Lucide icon name shown in the tab, e.g. 'sofa'. */
  icon: 'sofa' | 'cooking-pot' | 'bath' | 'brush' | 'bed-double';
  image: string;
  imageAlt: string;
  tasks: string[];
}

// Indian-home project references (DesignCafe) — see design-previews/indian-room-tabs.html.
// NOTE: third-party visual references; replace with licensed/original photography before production.
const base = 'https://media.designcafe.com/wp-content/uploads/';

export const serviceRooms: Record<string, ServiceRoom[]> = {
  'standard-clean': [
    {
      id: 'living',
      name: 'Living spaces',
      tab: 'Living',
      short: 'Dust-free surfaces, freshly polished fixtures.',
      icon: 'sofa',
      image: base + '2021/02/11194937/top-interior-contractors-in-mumbai.jpg',
      imageAlt:
        'Mumbai apartment living and dining room with TV unit and tiled flooring, DesignCafe project reference',
      tasks: ['High-touch surface dusting', 'Fixture polishing'],
    },
    {
      id: 'kitchen',
      name: 'Kitchen',
      tab: 'Kitchen',
      short: 'Everyday cooking mess, taken care of.',
      icon: 'cooking-pot',
      image: base + '2020/04/29160446/modular-kitchen-designs-mumbai.jpg',
      imageAlt:
        'Parallel kitchen in a Mumbai apartment with fitted cabinets and worktops, DesignCafe project reference',
      tasks: ['Countertops scrubbed', 'Stovetop degreased', 'Sink sanitized'],
    },
    {
      id: 'bathroom',
      name: 'Bathroom',
      tab: 'Bath',
      short: 'Fresh tiles, clean mirrors, shining fittings.',
      icon: 'bath',
      image: base + '2020/04/29155927/bathroom-design-designed-by-design-cafe.jpg',
      imageAlt: 'Mumbai apartment bathroom with grey tiles and basin, DesignCafe project reference',
      tasks: ['Tiles & commode sanitized', 'Mirrors sanitized', 'Chrome fittings polished'],
    },
    {
      id: 'floors',
      name: 'Floors',
      tab: 'Floors',
      short: 'A clean finish, from corner to corner.',
      icon: 'brush',
      // Cropped via imgix focal point (fp-y=0.95) so the floor at the bottom of the frame stays visible.
      image: 'https://images.unsplash.com/photo-1758273238415-01ec03d9ef27?auto=format&fit=crop&w=1400&h=444&crop=focalpoint&fp-y=0.95&q=85',
      imageAlt: 'A woman mopping a bright living room floor with a flat mop',
      tasks: ['High-power vacuuming', 'Antibacterial wet mopping'],
    },
    {
      id: 'linen',
      name: 'Bed linen',
      tab: 'Linen',
      short: 'A neatly made bed to come home to.',
      icon: 'bed-double',
      image: base + '2019/12/23134329/apartment-interiors-in-bangalore.jpg',
      imageAlt:
        'Bengaluru apartment bedroom with wooden bed and window seating, DesignCafe project reference',
      tasks: ['Bed linen straightened', 'Linen replaced upon request'],
    },
  ],
};

export function getServiceRooms(serviceId: string): ServiceRoom[] | undefined {
  return serviceRooms[serviceId];
}
