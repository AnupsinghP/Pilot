// Cleaning Club recurring subscription plans — see "Services and workflow.md".
export interface SubscriptionPlan {
  id: string;
  name: string;
  discountLabel: string;
  pricePerCleanInr: number;
  originalPriceInr: number;
  perks: string[];
  mostPopular?: boolean;
}

export const subscriptionPlans: SubscriptionPlan[] = [
  {
    id: 'plan-biweekly',
    name: 'Bi-Weekly Flow',
    discountLabel: 'Save 20%',
    pricePerCleanInr: 1199,
    originalPriceInr: 1499,
    perks: ['Dedicated primary cleaner', 'Free festive deep clean every 6 months', '1-tap pause or reschedule'],
    mostPopular: true,
  },
  {
    id: 'plan-weekly',
    name: 'Weekly Pristine',
    discountLabel: 'Save 25%',
    pricePerCleanInr: 1124,
    originalPriceInr: 1499,
    perks: ['Maximum savings', 'Free quarterly balcony wash', 'VIP priority support desk'],
  },
  {
    id: 'plan-monthly',
    name: 'Monthly Deep Reset',
    discountLabel: 'Save 12%',
    pricePerCleanInr: 1319,
    originalPriceInr: 1499,
    perks: ['Auto-pilot scheduling', 'Unused cleans roll over', '1-tap pause or reschedule'],
  },
];

export function getSubscriptionPlanById(id: string): SubscriptionPlan | undefined {
  return subscriptionPlans.find((p) => p.id === id);
}
