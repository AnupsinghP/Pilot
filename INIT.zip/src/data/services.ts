// Core, flat-rate cleaning journeys — see "Services and workflow.md" for the source spec.
export interface Service {
  id: string;
  name: string;
  description: string;
  /** Base price for a 1-bedroom / 1-bathroom home. */
  priceInr: number;
  durationMins: number;
  rating: number;
  ratingCount: number;
  instantAvailable: boolean;
  scheduledAvailable: boolean;
  icon: string; // MaterialCommunityIcons name
  tags: string[]; // e.g. ['Popular'], ['Guaranteed Pass']
  scope: string[]; // bullet list of inclusions
  /** Only the flagship Everyday Reset supports the Home-screen Room Customizer. */
  roomCustomizable: boolean;
}

export const services: Service[] = [
  {
    id: 'standard-clean',
    name: 'Everyday Reset',
    description: 'Maintenance house cleaning for living spaces, kitchen & bathroom.',
    priceInr: 1499,
    durationMins: 150,
    rating: 4.86,
    ratingCount: 5310,
    instantAvailable: true,
    scheduledAvailable: true,
    icon: 'broom',
    tags: ['Popular'],
    scope: [
      'High-touch surface dusting & fixture polish',
      'Kitchen countertop scrub, stovetop degreasing & sink sanitization',
      'Complete bathroom tile, commode & mirror sanitization with chrome polish',
      'High-power floor vacuuming and wet antibacterial mopping',
      'Bed linen straightening or full linen replacement upon request',
    ],
    roomCustomizable: true,
  },
  {
    id: 'move-out-deep',
    name: 'Move-Out Deep Clean',
    description: '100% Owner/Society Handover Guarantee with signed before/after photo report.',
    priceInr: 2999,
    durationMins: 270,
    rating: 4.87,
    ratingCount: 210,
    instantAvailable: false,
    scheduledAvailable: true,
    icon: 'shield-check-outline',
    tags: ['Guaranteed Pass'],
    scope: [
      'Top-to-bottom restoration designed to pass landlord and society checklists',
      'Interior kitchen cabinetry, drawers, and under-sink degreasing',
      'Deep kitchen chimney filter degreasing and exhaust fan cleanup',
      'Full refrigerator & freezer defrost wipe and sanitization (when emptied)',
      'Balcony pressure scrubbing and sliding glass track detail',
      'Hard water scale removal on glass shower partitions and ceramic tiles',
      'Formal signed Landlord Before/After Photo Inspection Report',
    ],
    roomCustomizable: false,
  },
  {
    id: 'seasonal-revive',
    name: 'Festive Pre-Season Deep Clean',
    description: 'Intensive deep clean for Diwali, Navratri & post-monsoon reset.',
    priceInr: 2499,
    durationMins: 210,
    rating: 4.83,
    ratingCount: 340,
    instantAvailable: false,
    scheduledAvailable: true,
    icon: 'leaf',
    tags: ['Festive Ready'],
    scope: [
      'Intensive deep clean targeting fine-particulate dust and post-monsoon dampness',
      'Sofa upholstery, carpet, and heavy drape dry vacuum extraction',
      'Window glass polishing, sliding tracks scrub, and mosquito mesh clearing',
      'High dusting of ceiling fan blades, cornice moldings, and AC vent louvers',
      'Under-bed and heavy furniture sweep and sanitization',
      'Organic botanical citrus & lavender essential oil room misting',
    ],
    roomCustomizable: false,
  },
  {
    id: 'pronto-express',
    name: 'Express 60-Min Rush',
    description: 'Same-day cleaner dispatched within 45–60 minutes.',
    priceInr: 999,
    durationMins: 90,
    rating: 4.79,
    ratingCount: 640,
    instantAvailable: true,
    scheduledAvailable: false,
    icon: 'flash-outline',
    tags: ['Fast Dispatch'],
    scope: [
      'Same-day cleaner dispatched within 45–60 minutes',
      'Priority speed clean for unexpected guests, house parties, or quick rescues',
      'Surface declutter, trash haul, kitchen slab wipe, and bathroom refresh',
      'Real-time GPS cleaner location tracker',
    ],
    roomCustomizable: false,
  },
];

export function getServiceById(id: string): Service | undefined {
  return services.find((s) => s.id === id);
}

/** ₹300 per extra bedroom beyond 1, ₹350 per extra bathroom beyond 1 (Everyday Reset only). */
export function computeRoomPrice(basePriceInr: number, bedrooms: number, bathrooms: number): number {
  const extraBedrooms = Math.max(0, bedrooms - 1);
  const extraBathrooms = Math.max(0, bathrooms - 1);
  return basePriceInr + extraBedrooms * 300 + extraBathrooms * 350;
}

