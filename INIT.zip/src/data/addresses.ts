export interface Address {
  id: string;
  label: string;
  line1: string;
  line2?: string;
  city: string;
}

export const addresses: Address[] = [
  {
    id: 'addr-home',
    label: 'Home',
    line1: '116/A, Windsor House',
    line2: 'Koramangala 5th Block',
    city: 'Bengaluru',
  },
  {
    id: 'addr-work',
    label: 'Work',
    line1: 'WeWork Prestige Atlanta',
    line2: 'Koramangala 1st Block',
    city: 'Bengaluru',
  },
];

export function getAddressById(id: string): Address | undefined {
  return addresses.find((a) => a.id === id);
}
