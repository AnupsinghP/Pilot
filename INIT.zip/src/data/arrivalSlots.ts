// Arrival window options for the "Complete Reservation" screen.
export type AccessMethod = 'lockbox' | 'frontdesk' | 'home';

export interface ArrivalSlot {
  id: string;
  label: string;
  timeRange: string;
  tag?: string;
  mode: 'instant' | 'scheduled';
}

export const arrivalSlots: ArrivalSlot[] = [
  { id: 'today-express', label: 'Today (Express)', timeRange: 'Within 60 mins', tag: 'Fast', mode: 'instant' },
  { id: 'tomorrow', label: 'Tomorrow', timeRange: '9:00 AM - 12:00 PM', tag: 'Recommended', mode: 'scheduled' },
  { id: 'this-saturday', label: 'This Saturday', timeRange: '10:00 AM - 1:00 PM', mode: 'scheduled' },
  { id: 'next-tuesday', label: 'Next Tuesday', timeRange: '8:30 AM - 11:30 AM', mode: 'scheduled' },
];

export function getArrivalSlotById(id: string): ArrivalSlot | undefined {
  return arrivalSlots.find((s) => s.id === id);
}

export const accessMethods: { id: AccessMethod; label: string }[] = [
  { id: 'lockbox', label: 'Lockbox / Keypad' },
  { id: 'frontdesk', label: 'Front Desk' },
  { id: 'home', label: "I'll be Home" },
];
