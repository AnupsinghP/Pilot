import React, { useEffect, useState } from 'react';
import { Alert, Linking, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { AlertTriangle, Circle, ChevronRight, MessageSquare, Phone, ShieldCheck } from 'lucide-react-native';
import { Avatar } from '@/src/components/Avatar';
import { Badge } from '@/src/components/Badge';
import { Button } from '@/src/components/Button';
import { getServiceById } from '@/src/data/services';
import { Professional } from '@/src/data/professionals';
import { fetchProfessional } from '@/src/services/professionalRepository';
import { Booking, useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

const MOCK_MILESTONES = [
  { room: 'Kitchen', task: 'Platform, tiles & sink degreased', done: true },
  { room: 'Bathroom', task: 'Fittings polished & sanitized', done: true },
  { room: 'Living Room', task: 'Dusting, sofa & floor mopped', done: false, inProgress: true },
  { room: 'Bedrooms', task: 'Dusting & floor mopped', done: false },
];

/** Live progress/checklist/chat view for an active booking — shared by the booking-detail route and the Live Clean tab. */
export function LiveTracking({ booking }: { booking: Booking }) {
  const router = useRouter();
  const { colors, radii, spacing, typography, shadow } = useTheme();
  const updateStatus = useBookingStore((s) => s.updateStatus);
  const [professional, setProfessional] = useState<Professional>();

  useEffect(() => {
    fetchProfessional(booking.professionalId).then(setProfessional);
  }, [booking.professionalId]);

  const service = getServiceById(booking.serviceId);
  const statusLabel =
    booking.status === 'completed'
      ? 'Completed'
      : booking.status === 'in_progress'
        ? 'Cleaning in progress'
        : 'Professional on the way';

  return (
    <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
      <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
        <View style={[styles.statusPill, { backgroundColor: colors.primaryMuted, borderRadius: radii.pill }]}>
          <Circle size={8} color={colors.success} fill={colors.success} />
          <Text style={{ marginLeft: 6, color: colors.textPrimary, fontSize: 11, fontWeight: '700' }}>
            {statusLabel.toUpperCase()}
          </Text>
        </View>
        {service ? (
          <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>{service.name}</Text>
        ) : null}
      </View>

      {professional ? (
        <Pressable
          onPress={() => router.push({ pathname: '/professional/[id]', params: { id: professional.id } })}
          style={[
            styles.proCard,
            shadow.card,
            { backgroundColor: colors.surface, borderRadius: radii.lg, marginTop: spacing.md, padding: spacing.md },
          ]}>
          <Avatar uri={professional.avatarUrl} name={professional.name} size={52} />
          <View style={{ marginLeft: spacing.md, flex: 1 }}>
            <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
              {professional.name}
            </Text>
            <Text style={{ color: colors.textSecondary, fontSize: typography.size.xs }}>
              ⭐ {professional.rating} · Assigned pro
            </Text>
          </View>
          <Pressable
            onPress={() => Linking.openURL('tel:+911234567890')}
            hitSlop={8}
            style={[styles.iconButton, { backgroundColor: colors.primaryMuted, marginRight: spacing.sm }]}>
            <Phone size={16} color={colors.primary} />
          </Pressable>
          <Pressable
            onPress={() => router.push({ pathname: '/booking/[id]/chat', params: { id: booking.id } })}
            hitSlop={8}
            style={[styles.iconButton, { backgroundColor: colors.primaryMuted }]}>
            <MessageSquare size={16} color={colors.primary} />
          </Pressable>
        </Pressable>
      ) : null}

      <View
        style={[
          styles.otpRow,
          { backgroundColor: colors.surfaceSubtle, borderRadius: radii.lg, marginTop: spacing.md, padding: spacing.md },
        ]}>
        <Text style={{ color: colors.textSecondary, fontSize: typography.size.xs }}>Check-in OTP</Text>
        <Text
          style={{ fontSize: typography.size.lg, fontWeight: typography.weight.bold, color: colors.textPrimary, letterSpacing: 4 }}>
          {booking.otp}
        </Text>
      </View>

      <Text
        style={{
          marginTop: spacing.xl,
          marginBottom: spacing.sm,
          fontWeight: typography.weight.semibold,
          color: colors.textPrimary,
        }}>
        Live inspection milestones
      </Text>
      <View style={{ gap: spacing.sm }}>
        {MOCK_MILESTONES.map((m) => (
          <View
            key={m.task}
            style={[
              styles.milestone,
              {
                backgroundColor: colors.surface,
                borderRadius: radii.lg,
                padding: spacing.md,
                borderLeftWidth: m.inProgress ? 3 : 0,
                borderLeftColor: colors.warning,
              },
            ]}>
            <View style={styles.row}>
              <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary, textTransform: 'uppercase' }}>
                {m.room}
              </Text>
              {m.done ? (
                <Badge label="Verified" tone="success" />
              ) : m.inProgress ? (
                <Badge label="In progress" tone="warning" />
              ) : null}
            </View>
            <Text style={{ marginTop: 4, color: colors.textPrimary, fontWeight: typography.weight.medium }}>
              {m.task}
            </Text>
          </View>
        ))}
      </View>

      <Pressable
        onPress={() => router.push('/trust/damage-protection')}
        style={[
          styles.linkRow,
          { backgroundColor: colors.surface, borderRadius: radii.lg, marginTop: spacing.xl, padding: spacing.md },
        ]}>
        <ShieldCheck size={18} color={colors.primary} />
        <Text style={{ marginLeft: spacing.md, flex: 1, color: colors.textPrimary }}>
          100% Damage protection guarantee
        </Text>
        <ChevronRight size={18} color={colors.textSecondary} />
      </Pressable>

      <Pressable
        onPress={() => Alert.alert('SOS triggered (mock)', 'Our safety team has been notified and will call you shortly.')}
        style={[
          styles.linkRow,
          { backgroundColor: `${colors.danger}15`, borderRadius: radii.lg, marginTop: spacing.sm, padding: spacing.md },
        ]}>
        <AlertTriangle size={18} color={colors.danger} />
        <Text style={{ marginLeft: spacing.md, flex: 1, color: colors.danger, fontWeight: typography.weight.semibold }}>
          SOS — I need help now
        </Text>
      </Pressable>

      {booking.status !== 'completed' ? (
        <View style={{ marginTop: spacing.xl }}>
          <Button
            label="Mark as completed (demo)"
            variant="secondary"
            onPress={() => {
              updateStatus(booking.id, 'completed');
              router.push({ pathname: '/booking/[id]/review', params: { id: booking.id } });
            }}
          />
        </View>
      ) : null}
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  statusPill: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', paddingHorizontal: 12, paddingVertical: 6 },
  proCard: { flexDirection: 'row', alignItems: 'center' },
  iconButton: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  otpRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  row: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  milestone: {},
  linkRow: { flexDirection: 'row', alignItems: 'center' },
});
