import React from 'react';
import { StyleSheet, View, ViewProps } from 'react-native';
import { SafeAreaView } from 'react-native-safe-area-context';
import { useTheme } from '@/src/theme/useTheme';

interface ScreenProps extends ViewProps {
  scroll?: boolean;
  edges?: ('top' | 'bottom' | 'left' | 'right')[];
}

/** Common screen wrapper: safe-area + themed background. */
export function Screen({ children, style, edges, ...rest }: ScreenProps) {
  const { colors } = useTheme();
  return (
    <SafeAreaView
      edges={edges ?? ['top']}
      style={[styles.container, { backgroundColor: colors.background }]}>
      <View style={[styles.content, style]} {...rest}>
        {children}
      </View>
    </SafeAreaView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1 },
  content: { flex: 1 },
});
