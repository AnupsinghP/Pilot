import React from 'react';
import { StyleSheet, Text, View } from 'react-native';
import { CheckCircle2 } from 'lucide-react-native';

interface TrustPillProps {
  label: string;
  tone?: 'light' | 'dark';
}

/** Small check + label pill used on dark hero cards to signal trust (verified, insured, etc.) */
export function TrustPill({ label, tone = 'dark' }: TrustPillProps) {
  const background = tone === 'dark' ? 'rgba(255,255,255,0.12)' : 'rgba(0,0,0,0.06)';
  const textColor = tone === 'dark' ? '#FFFFFF' : '#1A1A1A';

  return (
    <View style={[styles.pill, { backgroundColor: background }]}>
      <CheckCircle2 size={13} color="#8FD19E" />
      <Text style={[styles.label, { color: textColor }]}>{label}</Text>
    </View>
  );
}

const styles = StyleSheet.create({
  pill: {
    flexDirection: 'row',
    alignItems: 'center',
    borderRadius: 999,
    paddingHorizontal: 10,
    paddingVertical: 5,
    marginRight: 8,
    marginTop: 8,
  },
  label: {
    marginLeft: 4,
    fontSize: 11,
    fontWeight: '600',
  },
});
