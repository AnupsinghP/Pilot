import React, { useState } from 'react';
import { Image, Modal, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { ArrowUpRight, Bath, BedDouble, Brush, Check, CookingPot, Sofa, X } from 'lucide-react-native';
import { ServiceRoom } from '@/src/data/serviceRooms';
import { useTheme } from '@/src/theme/useTheme';

const roomIcons = {
  sofa: Sofa,
  'cooking-pot': CookingPot,
  bath: Bath,
  brush: Brush,
  'bed-double': BedDouble,
} as const;

interface RoomScopeTabsProps {
  rooms: ServiceRoom[];
  /** Index of the room shown initially (matches the design preview's Kitchen default). */
  initialIndex?: number;
}

/**
 * "Room-by-room tabs" service-scope explorer — one room at a time with a large
 * photo and checklist. See design-previews/service-concepts.html, concept 03.
 */
export function RoomScopeTabs({ rooms, initialIndex = 0 }: RoomScopeTabsProps) {
  const { colors, spacing, typography, radii, fonts } = useTheme();
  const [selectedIndex, setSelectedIndex] = useState(initialIndex);
  const [checklistVisible, setChecklistVisible] = useState(false);
  const room = rooms[selectedIndex];

  return (
    <View>
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ borderBottomWidth: 1, borderBottomColor: colors.border }}
        contentContainerStyle={{ gap: spacing.lg }}>
        {rooms.map((item, index) => {
          const selected = index === selectedIndex;
          const Icon = roomIcons[item.icon];
          return (
            <Pressable
              key={item.id}
              accessibilityRole="tab"
              accessibilityState={{ selected }}
              accessibilityLabel={item.name}
              onPress={() => setSelectedIndex(index)}
              style={{
                flexDirection: 'row',
                alignItems: 'center',
                gap: spacing.xs,
                paddingVertical: spacing.sm,
                borderBottomWidth: 2,
                borderBottomColor: selected ? colors.success : 'transparent',
              }}>
              <Icon size={16} color={selected ? colors.success : colors.textMuted} />
              <Text
                style={{
                  fontSize: typography.size.xs,
                  fontFamily: selected ? fonts.bodyBold : fonts.bodyRegular,
                  color: selected ? colors.success : colors.textSecondary,
                }}>
                {item.tab}
              </Text>
            </Pressable>
          );
        })}
      </ScrollView>

      <Image
        source={{ uri: room.image }}
        accessibilityLabel={room.imageAlt}
        style={{
          width: '100%',
          height: 188,
          marginTop: spacing.lg,
          borderRadius: radii.md,
          backgroundColor: colors.surfaceSubtle,
        }}
        resizeMode="cover"
      />

      <Text
        style={{
          marginTop: spacing.lg,
          fontSize: typography.size.xl,
          fontFamily: fonts.headingMedium,
          color: colors.textPrimary,
        }}>
        {room.name}
      </Text>
      <Text
        style={{
          marginTop: spacing.xs,
          marginBottom: spacing.md,
          fontSize: typography.size.xs,
          color: colors.textSecondary,
        }}>
        {room.short}
      </Text>

      <View style={{ gap: spacing.sm }}>
        {room.tasks.map((task) => (
          <View key={task} style={styles.checkRow}>
            <Check size={15} color={colors.success} />
            <Text style={{ marginLeft: spacing.sm, color: colors.textSecondary }}>{task}</Text>
          </View>
        ))}
      </View>

      <Pressable
        accessibilityRole="button"
        onPress={() => setChecklistVisible(true)}
        style={[styles.checkRow, { marginTop: spacing.xl }]}>
        <Text
          style={{
            fontSize: typography.size.xs,
            fontFamily: fonts.bodySemiBold,
            color: colors.success,
            marginRight: spacing.xs,
          }}>
          Full cleaning checklist
        </Text>
        <ArrowUpRight size={14} color={colors.success} />
      </Pressable>

      <Modal
        visible={checklistVisible}
        animationType="fade"
        transparent
        onRequestClose={() => setChecklistVisible(false)}>
        <View style={styles.backdrop}>
          <View
            style={[
              styles.sheet,
              { backgroundColor: colors.background, borderRadius: radii.lg, padding: spacing.xl },
            ]}>
            <View style={[styles.checkRow, { justifyContent: 'space-between' }]}>
              <Text
                style={{
                  fontSize: typography.size.lg,
                  fontFamily: fonts.headingSemiBold,
                  color: colors.textPrimary,
                }}>
                Full cleaning checklist
              </Text>
              <Pressable
                accessibilityRole="button"
                accessibilityLabel="Close checklist"
                onPress={() => setChecklistVisible(false)}
                hitSlop={8}>
                <X size={20} color={colors.textSecondary} />
              </Pressable>
            </View>
            <ScrollView style={{ marginTop: spacing.lg }}>
              {rooms.map((item) => (
                <View key={item.id} style={{ marginBottom: spacing.lg }}>
                  <Text
                    style={{
                      fontFamily: fonts.bodySemiBold,
                      fontSize: typography.size.sm,
                      color: colors.textPrimary,
                      marginBottom: spacing.xs,
                    }}>
                    {item.name}
                  </Text>
                  {item.tasks.map((task) => (
                    <View key={task} style={[styles.checkRow, { marginTop: spacing.xs }]}>
                      <Check size={14} color={colors.success} />
                      <Text style={{ marginLeft: spacing.sm, color: colors.textSecondary }}>
                        {task}
                      </Text>
                    </View>
                  ))}
                </View>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </View>
  );
}

const styles = StyleSheet.create({
  checkRow: { flexDirection: 'row', alignItems: 'center' },
  backdrop: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.4)',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 16,
  },
  sheet: { width: '100%', maxWidth: 380, maxHeight: '80%' },
});
