import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { CalendarClock, Leaf, PartyPopper, Snowflake } from 'lucide-react-native';
import { Badge } from '@/src/components/Badge';
import { Button } from '@/src/components/Button';
import { seasonalPlans } from '@/src/data/seasonalPlans';
import { Service } from '@/src/data/services';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

const SEASON_ICONS = { spring: Leaf, autumn: Snowflake, holiday: PartyPopper } as const;

export function SeasonalDetail({ service }: { service: Service }) {
  const router = useRouter();
  const { colors, radii, spacing, typography, fonts, shadow } = useTheme();
  const setDraft = useBookingStore((s) => s.setDraft);
  const [seasonId, setSeasonId] = useState(seasonalPlans[0].id);
  const [mistSelected, setMistSelected] = useState(false);

  const plan = seasonalPlans.find((p) => p.id === seasonId) ?? seasonalPlans[0];
  const total = plan.priceInr + (mistSelected ? 199 : 0);

  function handleBook() {
    setDraft({
      serviceId: service.id,
      mode: 'scheduled',
      addOnIds: mistSelected ? ['addon-mist'] : [],
      seasonVariantId: seasonId,
    });
    router.push('/booking/address');
  }

  return (
    <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}>
      <View style={[styles.segmentRow, { backgroundColor: colors.surfaceSubtle, borderRadius: radii.pill, padding: 4 }]}>
        {seasonalPlans.map((p) => {
          const Icon = SEASON_ICONS[p.id as keyof typeof SEASON_ICONS];
          const selected = p.id === seasonId;
          return (
            <Pressable
              key={p.id}
              onPress={() => setSeasonId(p.id)}
              style={[
                styles.segmentItem,
                {
                  backgroundColor: selected ? colors.surface : 'transparent',
                  borderRadius: radii.pill,
                },
              ]}>
              <Icon size={16} color={selected ? colors.primary : colors.textSecondary} />
              <Text
                style={{
                  marginLeft: 6,
                  fontSize: typography.size.xs,
                  fontWeight: typography.weight.medium,
                  color: selected ? colors.textPrimary : colors.textSecondary,
                  textTransform: 'capitalize',
                }}>
                {p.id}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View
        style={[
          styles.card,
          shadow.card,
          { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md, marginTop: spacing.lg },
        ]}>
        <View style={styles.headerRow}>
          <Badge label={plan.badge} tone="success" />
          <View style={{ alignItems: 'flex-end' }}>
            <Text style={{ fontSize: typography.size.lg, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
              ₹{plan.priceInr}
            </Text>
            <Text style={{ fontSize: 10, color: colors.textSecondary }}>Flat Rate</Text>
          </View>
        </View>
        <Text style={{ marginTop: spacing.sm, fontSize: typography.size.lg, fontFamily: fonts.headingSemiBold, color: colors.textPrimary }}>
          {plan.name}
        </Text>
        <Text style={{ marginTop: 2, color: colors.textSecondary, fontSize: typography.size.sm }}>
          {plan.description}
        </Text>

        <View style={[styles.divider, { backgroundColor: colors.border, marginVertical: spacing.md }]} />

        <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary, marginBottom: spacing.sm }}>
          Included Deep Cleans:
        </Text>
        <View style={{ gap: 6 }}>
          {plan.includes.map((line) => (
            <View key={line} style={styles.row}>
              <Text style={{ color: colors.success, marginRight: spacing.sm }}>✓</Text>
              <Text style={{ flex: 1, color: colors.textSecondary, fontSize: typography.size.sm }}>{line}</Text>
            </View>
          ))}
        </View>

        <Pressable
          onPress={() => setMistSelected((v) => !v)}
          style={[
            styles.mistCard,
            {
              backgroundColor: colors.primaryMuted,
              borderRadius: radii.md,
              marginTop: spacing.md,
              padding: spacing.sm,
              borderWidth: mistSelected ? 1.5 : 0,
              borderColor: colors.success,
            },
          ]}>
          <Leaf size={16} color={colors.success} />
          <View style={{ marginLeft: spacing.sm, flex: 1 }}>
            <Text style={{ fontWeight: typography.weight.medium, color: colors.textPrimary, fontSize: typography.size.sm }}>
              Organic Botanical Essential Mist
            </Text>
            <Text style={{ fontSize: 11, color: colors.textSecondary }}>
              Eucalyptus & Lavender air purifying mist
            </Text>
          </View>
          <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>+₹199</Text>
        </Pressable>
      </View>

      <View
        style={[
          styles.card,
          { backgroundColor: colors.surfaceSubtle, borderRadius: radii.lg, padding: spacing.md, marginTop: spacing.md },
        ]}>
        <View style={styles.headerRow}>
          <View style={styles.row}>
            <CalendarClock size={16} color={colors.textPrimary} />
            <Text style={{ marginLeft: spacing.sm, fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
              Smart Seasonal Cadence
            </Text>
          </View>
          <Badge label="Auto-Pilot" tone="success" />
        </View>
        <Text style={{ marginTop: spacing.xs, fontSize: typography.size.xs, color: colors.textSecondary }}>
          Never let dust accumulate. Lock in 4 quarterly refreshes per year and save an extra 15% with automatic date
          confirmations.
        </Text>
      </View>

      <View style={{ marginTop: spacing.xl }}>
        <Button label={`Book Seasonal Reset (₹${total})`} onPress={handleBook} />
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  segmentRow: { flexDirection: 'row' },
  segmentItem: { flex: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', paddingVertical: 8 },
  card: {},
  headerRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  divider: { height: StyleSheet.hairlineWidth },
  row: { flexDirection: 'row', alignItems: 'center' },
  mistCard: { flexDirection: 'row', alignItems: 'center' },
});
