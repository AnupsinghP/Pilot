import React from 'react';
import { Pressable, StyleProp, StyleSheet, ViewStyle } from 'react-native';
import { useRouter } from 'expo-router';
import { ArrowLeft } from 'lucide-react-native';
import { useTheme } from '@/src/theme/useTheme';

interface BackButtonProps {
  /** Position overrides (e.g. top/left) — the button is absolutely positioned. */
  style?: StyleProp<ViewStyle>;
}

/** Floating circular back arrow for headerless detail screens. Position it with `style`. */
export function BackButton({ style }: BackButtonProps) {
  const router = useRouter();
  const { colors, radii } = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel="Go back"
      onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))}
      hitSlop={8}
      style={[
        styles.button,
        {
          backgroundColor: colors.surface,
          borderColor: colors.border,
          borderRadius: radii.pill,
        },
        style,
      ]}>
      <ArrowLeft size={20} color={colors.textPrimary} />
    </Pressable>
  );
}

const styles = StyleSheet.create({
  button: {
    position: 'absolute',
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 1,
  },
});