import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { ChevronRight } from 'lucide-react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme/useTheme';

interface SummaryCardProps {
  title: string;
  subtitle: string;
  previewIcons: string[];
  onPress?: () => void;
}

/** Compact entry-point card that opens a full browse screen (categories/services) when tapped. */
export function SummaryCard({ title, subtitle, previewIcons, onPress }: SummaryCardProps) {
  const { colors, tints, radii, spacing, typography, shadow } = useTheme();

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        shadow.card,
        {
          backgroundColor: colors.surface,
          borderRadius: radii.xl,
          padding: spacing.md,
          opacity: pressed ? 0.92 : 1,
        },
      ]}>
      <View style={styles.previewRow}>
        {previewIcons.slice(0, 4).map((icon, i) => (
          <View
            key={icon + i}
            style={[
              styles.previewIcon,
              { backgroundColor: tints[i % tints.length], marginLeft: i === 0 ? 0 : -10 },
            ]}>
            <MaterialCommunityIcons name={icon as any} size={16} color={colors.primary} />
          </View>
        ))}
      </View>
      <Text
        style={{
          marginTop: spacing.sm,
          fontSize: typography.size.md,
          fontWeight: typography.weight.semibold,
          color: colors.textPrimary,
        }}>
        {title}
      </Text>
      <View style={styles.footerRow}>
        <Text style={{ flex: 1, fontSize: typography.size.xs, color: colors.textSecondary }}>{subtitle}</Text>
        <ChevronRight size={18} color={colors.textSecondary} />
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: { flex: 1 },
  previewRow: { flexDirection: 'row', alignItems: 'center' },
  previewIcon: {
    width: 32,
    height: 32,
    borderRadius: 16,
    alignItems: 'center',
    justifyContent: 'center',
    borderWidth: 2,
    borderColor: '#fff',
  },
  footerRow: { flexDirection: 'row', alignItems: 'center', marginTop: 6 },
});
