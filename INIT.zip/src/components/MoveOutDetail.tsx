import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Switch, Text, TextInput, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Mail, ShieldCheck, Square, SquareCheck } from 'lucide-react-native';
import { Badge } from '@/src/components/Badge';
import { Button } from '@/src/components/Button';
import { addOns } from '@/src/data/addOns';
import { Service } from '@/src/data/services';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

// Move-Out's "Furnished" and "Botanical Mist" add-ons are handled separately (Property State / Seasonal), not in this checklist.
const INSPECTION_ADD_ON_IDS = addOns
  .filter((a) => a.id !== 'addon-furnished' && a.id !== 'addon-mist')
  .map((a) => a.id);

export function MoveOutDetail({ service }: { service: Service }) {
  const router = useRouter();
  const { colors, hero, radii, spacing, typography, fonts, shadow } = useTheme();
  const setDraft = useBookingStore((s) => s.setDraft);
  const [inspectionPassOn, setInspectionPassOn] = useState(true);
  const [landlordEmail, setLandlordEmail] = useState('');
  const [propertyState, setPropertyState] = useState<'empty' | 'furnished'>('empty');
  const [selectedAddOns, setSelectedAddOns] = useState<string[]>(['addon-chimney']);

  const inspectionAddOns = addOns.filter((a) => INSPECTION_ADD_ON_IDS.includes(a.id));
  const furnishedSurcharge = propertyState === 'furnished' ? 499 : 0;
  const addOnsTotal = selectedAddOns.reduce(
    (sum, id) => sum + (addOns.find((a) => a.id === id)?.priceInr ?? 0),
    0
  );
  const total = service.priceInr + furnishedSurcharge + addOnsTotal;

  function toggleAddOn(id: string) {
    setSelectedAddOns((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  function handleSchedule() {
    setDraft({
      serviceId: service.id,
      mode: 'scheduled',
      addOnIds: selectedAddOns,
      propertyState,
      landlordEmail: inspectionPassOn ? landlordEmail.trim() || undefined : undefined,
    });
    router.push('/booking/address');
  }

  return (
    <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: 120 }}>
      <Badge label="🛡️ 100% Deposit-Back Guarantee" tone="success" />
      <Text style={{ marginTop: spacing.sm, fontSize: 24, fontFamily: fonts.headingSemiBold, color: colors.textPrimary }}>
        Move-Out Deep Clean
      </Text>
      <Text style={{ marginTop: 4, color: colors.textSecondary }}>
        Inspection-grade end-of-tenancy clean. If your landlord flags any item within 48 hours, we re-clean free of
        charge.
      </Text>

      <View style={[styles.darkCard, { backgroundColor: hero.background, borderRadius: radii.lg, marginTop: spacing.lg, padding: spacing.md }]}>
        <View style={styles.row}>
          <ShieldCheck size={18} color={hero.text} />
          <View style={{ marginLeft: spacing.sm, flex: 1 }}>
            <Text style={{ color: hero.text, fontWeight: typography.weight.semibold }}>Landlord Inspection Pass</Text>
            <Text style={{ color: hero.textMuted, fontSize: typography.size.xs }}>
              Digital signed PDF sent to your landlord
            </Text>
          </View>
          <Switch value={inspectionPassOn} onValueChange={setInspectionPassOn} trackColor={{ true: colors.success }} />
        </View>

        {inspectionPassOn ? (
          <>
            <View style={{ marginTop: spacing.md, gap: 6 }}>
              <Text style={{ color: hero.text, fontSize: typography.size.xs }}>
                ✓ Full photo evidence package before & after
              </Text>
              <Text style={{ color: hero.text, fontSize: typography.size.xs }}>
                ✓ Free 48-hour contractor return if requested by agent
              </Text>
            </View>
            <View
              style={[
                styles.emailRow,
                { backgroundColor: 'rgba(255,255,255,0.1)', borderRadius: radii.md, marginTop: spacing.md },
              ]}>
              <Mail size={16} color={hero.textMuted} />
              <TextInput
                value={landlordEmail}
                onChangeText={setLandlordEmail}
                placeholder="Property Manager / Landlord Email (Optional)"
                placeholderTextColor={hero.textMuted}
                style={{ marginLeft: spacing.sm, flex: 1, color: hero.text, paddingVertical: 10 }}
              />
            </View>
          </>
        ) : null}
      </View>

      <Text style={{ marginTop: spacing.xl, marginBottom: spacing.sm, fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
        Property State
      </Text>
      <View style={styles.row}>
        {(['empty', 'furnished'] as const).map((state) => {
          const selected = propertyState === state;
          return (
            <Pressable
              key={state}
              onPress={() => setPropertyState(state)}
              style={[
                styles.stateChip,
                {
                  backgroundColor: selected ? colors.surface : colors.surfaceSubtle,
                  borderRadius: radii.pill,
                  borderWidth: selected ? 1.5 : 0,
                  borderColor: colors.primary,
                  marginRight: spacing.sm,
                },
              ]}>
              <Text style={{ color: selected ? colors.textPrimary : colors.textSecondary, fontWeight: typography.weight.medium }}>
                {state === 'empty' ? 'Empty / Unfurnished' : 'Furnished (+₹499)'}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <Text
        style={{
          marginTop: spacing.xl,
          marginBottom: spacing.sm,
          fontSize: 12,
          fontWeight: typography.weight.semibold,
          color: colors.textSecondary,
          letterSpacing: 1,
          textTransform: 'uppercase',
        }}>
        Inspection Add-Ons
      </Text>
      <View style={{ gap: spacing.sm }}>
        {inspectionAddOns.map((addOn) => {
          const selected = selectedAddOns.includes(addOn.id);
          const CheckboxIcon = selected ? SquareCheck : Square;
          return (
            <Pressable
              key={addOn.id}
              onPress={() => toggleAddOn(addOn.id)}
              style={[
                styles.addOnRow,
                shadow.card,
                { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md },
              ]}>
              <CheckboxIcon size={20} color={selected ? colors.primary : colors.textSecondary} />
              <View style={{ marginLeft: spacing.md, flex: 1 }}>
                <View style={styles.row}>
                  <Text style={{ color: colors.textPrimary, fontWeight: typography.weight.medium }}>{addOn.name}</Text>
                  {addOn.priceInr >= 600 ? <Badge label="Popular" tone="warning" /> : null}
                </View>
                <Text style={{ marginTop: 2, fontSize: typography.size.xs, color: colors.textSecondary }}>
                  {addOn.description}
                </Text>
              </View>
              <Text style={{ color: colors.textPrimary, fontWeight: typography.weight.semibold }}>
                +₹{addOn.priceInr}
              </Text>
            </Pressable>
          );
        })}
      </View>

      <View style={{ height: spacing.xxl }} />

      <View
        style={[
          styles.footer,
          shadow.card,
          { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md },
        ]}>
        <View>
          <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>Total Guaranteed Quote</Text>
          <Text style={{ fontSize: typography.size.xl, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
            ₹{total}
          </Text>
        </View>
        <View style={{ flex: 1, marginLeft: spacing.md }}>
          <Button label="Schedule Move-Out" onPress={handleSchedule} />
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  darkCard: {},
  row: { flexDirection: 'row', alignItems: 'center' },
  emailRow: { flexDirection: 'row', alignItems: 'center', paddingHorizontal: 12 },
  stateChip: { paddingHorizontal: 14, paddingVertical: 10 },
  addOnRow: { flexDirection: 'row', alignItems: 'center' },
  footer: { flexDirection: 'row', alignItems: 'center' },
});
