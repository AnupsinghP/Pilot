import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { useTheme } from '@/src/theme/useTheme';
import { Service } from '@/src/data/services';
import { Badge } from './Badge';

interface CoreServiceCardProps {
  service: Service;
  index?: number;
  onPress?: () => void;
}

/** 2-column flagship service card used on the Explore screen (Everyday Reset, Move-Out, etc.). */
export function CoreServiceCard({ service, index = 0, onPress }: CoreServiceCardProps) {
  const { colors, tints, radii, spacing, typography, shadow } = useTheme();
  const tint = tints[index % tints.length];

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        shadow.card,
        {
          backgroundColor: colors.surface,
          borderRadius: radii.xl,
          padding: spacing.md,
          opacity: pressed ? 0.92 : 1,
        },
      ]}>
      <View style={styles.headerRow}>
        <View style={[styles.iconWrap, { backgroundColor: tint, borderRadius: radii.md }]}>
          <MaterialCommunityIcons name={service.icon as any} size={22} color={colors.primary} />
        </View>
        {service.tags[0] ? <Badge label={service.tags[0]} tone="primary" /> : null}
      </View>

      <Text
        numberOfLines={1}
        style={{
          marginTop: spacing.sm,
          fontSize: typography.size.sm,
          fontWeight: typography.weight.semibold,
          color: colors.textPrimary,
        }}>
        {service.name}
      </Text>
      <Text
        numberOfLines={2}
        style={{ marginTop: 2, fontSize: typography.size.xs, color: colors.textSecondary, minHeight: 30 }}>
        {service.description}
      </Text>

      <View style={[styles.footerRow, { marginTop: spacing.sm }]}>
        <Text style={{ fontSize: typography.size.sm, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
          From ₹{service.priceInr}
        </Text>
        <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>
          {(service.durationMins / 60).toFixed(1)}h
        </Text>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {
    width: '48%',
    marginBottom: 14,
  },
  headerRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  iconWrap: {
    width: 40,
    height: 40,
    alignItems: 'center',
    justifyContent: 'center',
  },
  footerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
});
