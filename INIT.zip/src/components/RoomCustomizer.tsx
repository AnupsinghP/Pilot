import React, { useState } from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Minus, Plus, SlidersHorizontal } from 'lucide-react-native';
import { Button } from './Button';
import { computeRoomPrice, getServiceById } from '@/src/data/services';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

const EVERYDAY_RESET_ID = 'standard-clean';

function Stepper({
  label,
  value,
  onChange,
}: {
  label: string;
  value: number;
  onChange: (next: number) => void;
}) {
  const { colors, radii, spacing, typography } = useTheme();
  return (
    <View style={{ flex: 1 }}>
      <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>{label}</Text>
      <View style={[styles.stepperRow, { marginTop: spacing.xs }]}>
        <Pressable
          onPress={() => onChange(Math.max(1, value - 1))}
          style={[styles.stepperButton, { backgroundColor: colors.surfaceSubtle, borderRadius: radii.pill }]}>
          <Minus size={14} color={colors.textPrimary} />
        </Pressable>
        <Text style={{ marginHorizontal: spacing.md, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
          {value}
        </Text>
        <Pressable
          onPress={() => onChange(Math.min(6, value + 1))}
          style={[styles.stepperButton, { backgroundColor: colors.surfaceSubtle, borderRadius: radii.pill }]}>
          <Plus size={14} color={colors.textPrimary} />
        </Pressable>
      </View>
    </View>
  );
}

export function RoomCustomizer() {
  const router = useRouter();
  const { colors, radii, spacing, typography, shadow } = useTheme();
  const setDraft = useBookingStore((s) => s.setDraft);
  const [bedrooms, setBedrooms] = useState(2);
  const [bathrooms, setBathrooms] = useState(2);
  const service = getServiceById(EVERYDAY_RESET_ID);
  const estimate = service ? computeRoomPrice(service.priceInr, bedrooms, bathrooms) : 0;

  return (
    <View
      style={[
        styles.card,
        shadow.card,
        { backgroundColor: colors.surface, borderRadius: radii.xl, padding: spacing.md },
      ]}>
      <View style={styles.headerRow}>
        <View style={styles.headerLeft}>
          <SlidersHorizontal size={16} color={colors.primary} />
          <Text style={{ marginLeft: spacing.xs, fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
            Room Customizer
          </Text>
        </View>
        <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>Est: ₹{estimate}</Text>
      </View>

      <View style={[styles.stepperGroup, { marginTop: spacing.md }]}>
        <Stepper label="Bedrooms" value={bedrooms} onChange={setBedrooms} />
        <View style={{ width: spacing.lg }} />
        <Stepper label="Bathrooms" value={bathrooms} onChange={setBathrooms} />
      </View>

      <View style={{ marginTop: spacing.md }}>
        <Button
          label="Continue with Everyday Reset"
          onPress={() => {
            setDraft({
              serviceId: EVERYDAY_RESET_ID,
              mode: 'instant',
              bedrooms,
              bathrooms,
              addOnIds: [],
            });
            router.push('/booking/address');
          }}
        />
      </View>
    </View>
  );
}

const styles = StyleSheet.create({
  card: {},
  headerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  headerLeft: { flexDirection: 'row', alignItems: 'center' },
  stepperGroup: { flexDirection: 'row' },
  stepperRow: { flexDirection: 'row', alignItems: 'center' },
  stepperButton: { width: 28, height: 28, alignItems: 'center', justifyContent: 'center' },
});
