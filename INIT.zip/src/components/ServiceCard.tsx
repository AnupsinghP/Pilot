import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { MaterialCommunityIcons } from '@expo/vector-icons';
import { Clock, Heart } from 'lucide-react-native';
import { useTheme } from '@/src/theme/useTheme';
import { Service } from '@/src/data/services';
import { useBookmarkStore } from '@/src/store/bookmarkStore';
import { Badge } from './Badge';

interface ServiceCardProps {
  service: Service;
  onPress?: () => void;
}

export function ServiceCard({ service, onPress }: ServiceCardProps) {
  const { colors, radii, spacing, typography, shadow, tints } = useTheme();
  const bookmarked = useBookmarkStore((s) => s.isBookmarked(service.id));
  const toggleBookmark = useBookmarkStore((s) => s.toggleBookmark);

  return (
    <Pressable
      onPress={onPress}
      style={({ pressed }) => [
        styles.card,
        shadow.card,
        {
          backgroundColor: colors.surface,
          borderRadius: radii.xl,
          padding: spacing.md,
          opacity: pressed ? 0.92 : 1,
        },
      ]}>
      <View style={styles.headerRow}>
        <View style={[styles.thumb, { backgroundColor: tints[0] }]}>
          <MaterialCommunityIcons name={service.icon as any} size={20} color={colors.primary} />
        </View>
        <View style={styles.headerActions}>
          {service.tags[0] ? <Badge label={service.tags[0]} tone="primary" /> : null}
          <Pressable onPress={() => toggleBookmark(service.id)} hitSlop={8} style={{ marginLeft: spacing.xs }}>
            <Heart
              size={18}
              color={bookmarked ? colors.danger : colors.textSecondary}
              fill={bookmarked ? colors.danger : 'transparent'}
            />
          </Pressable>
        </View>
      </View>

      <Text
        style={{
          marginTop: spacing.sm,
          fontSize: typography.size.md,
          fontWeight: typography.weight.semibold,
          color: colors.textPrimary,
        }}>
        {service.name}
      </Text>
      <Text
        numberOfLines={2}
        style={{ marginTop: 2, color: colors.textSecondary, fontSize: typography.size.xs, minHeight: 30 }}>
        {service.description}
      </Text>

      <View style={[styles.divider, { backgroundColor: colors.border, marginVertical: spacing.md }]} />

      <View style={styles.footerRow}>
        <View>
          <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>From</Text>
          <Text style={{ fontSize: typography.size.lg, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
            ₹{service.priceInr}
          </Text>
        </View>
        <View style={styles.metaItem}>
          <Clock size={14} color={colors.textSecondary} />
          <Text style={{ marginLeft: 4, fontSize: typography.size.xs, color: colors.textSecondary }}>
            {service.durationMins} min
          </Text>
        </View>
      </View>
    </Pressable>
  );
}

const styles = StyleSheet.create({
  card: {},
  headerRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  headerActions: { flexDirection: 'row', alignItems: 'center' },
  thumb: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  metaItem: { flexDirection: 'row', alignItems: 'center' },
  divider: { height: StyleSheet.hairlineWidth },
  footerRow: { flexDirection: 'row', alignItems: 'flex-end', justifyContent: 'space-between' },
});
