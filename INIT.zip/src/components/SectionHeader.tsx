import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';
import { useTheme } from '@/src/theme/useTheme';

interface SectionHeaderProps {
  title: string;
  actionLabel?: string;
  onActionPress?: () => void;
  /** Small, letter-spaced, uppercase label style instead of a large heading. */
  eyebrow?: boolean;
}

export function SectionHeader({ title, actionLabel, onActionPress, eyebrow }: SectionHeaderProps) {
  const { colors, typography, spacing } = useTheme();
  return (
    <View style={[styles.row, { marginBottom: spacing.sm }]}>
      <Text
        style={
          eyebrow
            ? {
                fontSize: 12,
                fontWeight: typography.weight.semibold,
                color: colors.textSecondary,
                letterSpacing: 1,
                textTransform: 'uppercase',
              }
            : {
                fontSize: typography.size.lg,
                fontWeight: typography.weight.semibold,
                color: colors.textPrimary,
              }
        }>
        {title}
      </Text>
      {actionLabel ? (
        <Pressable onPress={onActionPress} hitSlop={8}>
          <Text style={{ fontSize: typography.size.sm, color: colors.primary }}>
            {actionLabel}
          </Text>
        </Pressable>
      ) : null}
    </View>
  );
}

const styles = StyleSheet.create({
  row: {
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});
