import React from 'react';
import { Pressable, StyleSheet, Text, View } from 'react-native';

interface BadgeProps {
  label: string;
  tone?: 'primary' | 'success' | 'warning' | 'neutral';
}

import { useTheme } from '@/src/theme/useTheme';

export function Badge({ label, tone = 'neutral' }: BadgeProps) {
  const { colors, radii, spacing, typography } = useTheme();
  const toneColor =
    tone === 'primary'
      ? colors.primary
      : tone === 'success'
        ? colors.success
        : tone === 'warning'
          ? colors.warning
          : colors.textSecondary;
  const toneBackground = tone === 'neutral' ? colors.background : `${toneColor}22`;

  return (
    <View
      style={[
        styles.badge,
        {
          backgroundColor: toneBackground,
          borderRadius: radii.pill,
          paddingHorizontal: spacing.sm,
          paddingVertical: 3,
        },
      ]}>
      <Text style={{ color: toneColor, fontSize: typography.size.xs, fontWeight: typography.weight.medium }}>
        {label}
      </Text>
    </View>
  );
}

const styles = StyleSheet.create({
  badge: {
    alignSelf: 'flex-start',
  },
});

// Re-exported for convenience where a pressable badge is needed (e.g. filters)
export function PressableBadge({
  label,
  selected,
  onPress,
}: {
  label: string;
  selected?: boolean;
  onPress?: () => void;
}) {
  const { colors, radii, spacing, typography } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      style={[
        styles.badge,
        {
          borderColor: selected ? colors.primary : colors.border,
          backgroundColor: selected ? colors.primaryMuted : colors.surface,
          borderRadius: radii.pill,
          borderWidth: 1.5,
          paddingHorizontal: spacing.md,
          paddingVertical: spacing.xs,
        },
      ]}>
      <Text
        style={{
          color: selected ? colors.primary : colors.textSecondary,
          fontSize: typography.size.sm,
          fontWeight: typography.weight.medium,
        }}>
        {label}
      </Text>
    </Pressable>
  );
}
