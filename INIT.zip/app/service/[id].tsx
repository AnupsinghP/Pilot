import React, { useEffect, useState } from 'react';
import { ActivityIndicator, Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { ArrowLeft, Droplets, Sparkles, Wind, Home, UtensilsCrossed, Waves, Broom } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Badge } from '@/src/components/Badge';
import { Button } from '@/src/components/Button';
import { MoveOutDetail } from '@/src/components/MoveOutDetail';
import { SeasonalDetail } from '@/src/components/SeasonalDetail';
import { RoomScopeTabs } from '@/src/components/RoomScopeTabs';
import { BackButton } from '@/src/components/BackButton';
import { Service } from '@/src/data/services';
import { getServiceRooms } from '@/src/data/serviceRooms';
import { fetchService } from '@/src/services/serviceRepository';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

type ScopeCategory = 'surfaces' | 'kitchen' | 'bathroom' | 'flooring';

interface CategorizedScope {
  surfaces: string[];
  kitchen: string[];
  bathroom: string[];
  flooring: string[];
}

const categorizeScope = (scope: string[]): CategorizedScope => {
  const categories: CategorizedScope = {
    surfaces: [],
    kitchen: [],
    bathroom: [],
    flooring: [],
  };

  scope.forEach((item) => {
    const lower = item.toLowerCase();

    if (lower.includes('floor') || lower.includes('vacuum') || lower.includes('mopping')) {
      categories.flooring.push(item);
    } else if (
      lower.includes('kitchen') ||
      lower.includes('countertop') ||
      lower.includes('stovetop') ||
      lower.includes('sink')
    ) {
      categories.kitchen.push(item);
    } else if (
      lower.includes('bathroom') ||
      lower.includes('tile') ||
      lower.includes('commode') ||
      lower.includes('mirror') ||
      lower.includes('chrome')
    ) {
      categories.bathroom.push(item);
    } else {
      categories.surfaces.push(item);
    }
  });

  return categories;
};

export default function ServiceDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const setDraft = useBookingStore((s) => s.setDraft);
  const { colors, spacing, typography, radii, fonts } = useTheme();
  const [service, setService] = useState<Service>();
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    async function load() {
      const svc = await fetchService(id);
      if (active) {
        setService(svc);
        setLoading(false);
      }
    }
    load();
    return () => {
      active = false;
    };
  }, [id]);

  if (loading || !service) {
    return (
      <Screen>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      </Screen>
    );
  }

  if (service.id === 'move-out-deep') {
    return (
      <Screen edges={['top']}>
        <Stack.Screen options={{ headerShown: false }} />
        <MoveOutDetail service={service} />
        <BackButton style={{ top: spacing.md, left: spacing.lg }} />
      </Screen>
    );
  }

  if (service.id === 'seasonal-revive') {
    return (
      <Screen edges={['top']}>
        <Stack.Screen options={{ headerShown: false }} />
        <SeasonalDetail service={service} />
        <BackButton style={{ top: spacing.md, left: spacing.lg }} />
      </Screen>
    );
  }

  return (
    <Screen edges={['top']}>
      {/* Header hidden: compact back + title row, then the room tabs. */}
      <Stack.Screen options={{ headerShown: false }} />
      <ScrollView
        contentContainerStyle={{
          padding: spacing.lg,
          paddingTop: spacing.md,
          paddingBottom: spacing.xxl,
        }}>
        <View style={[styles.row, { gap: spacing.sm, marginBottom: spacing.md }]}>
          <Pressable
            accessibilityRole="button"
            accessibilityLabel="Go back"
            onPress={() => (router.canGoBack() ? router.back() : router.replace('/'))}
            hitSlop={8}
            style={{
              width: 40,
              height: 40,
              alignItems: 'center',
              justifyContent: 'center',
              borderWidth: 1,
              borderRadius: radii.pill,
              backgroundColor: colors.surface,
              borderColor: colors.border,
            }}>
            <ArrowLeft size={20} color={colors.textPrimary} />
          </Pressable>
          <Text
            style={{
              flex: 1,
              fontSize: typography.size.lg,
              fontFamily: fonts.headingSemiBold,
              color: colors.textPrimary,
            }}>
            {service.name}
          </Text>
        </View>
        <Text style={{ marginTop: spacing.xs, color: colors.textSecondary }}>{service.description}</Text>

        <View style={[styles.row, { marginTop: spacing.md, gap: spacing.sm }]}>
          <Badge label={`⭐ ${service.rating.toFixed(2)} (${service.ratingCount})`} />
          <Badge label={`${service.durationMins} min`} />
        </View>

        <Text
          style={{
            marginTop: spacing.xl,
            marginBottom: spacing.md,
            fontWeight: typography.weight.semibold,
            color: colors.textPrimary,
          }}>
          What's included
        </Text>

        {(() => {
          const rooms = getServiceRooms(service.id);
          if (rooms) {
            return <RoomScopeTabs rooms={rooms} />;
          }

          const categorized = categorizeScope(service.scope);
          const getCategoryIcon = (category: ScopeCategory) => {
            const iconProps = { size: 20, color: colors.primary };
            switch (category) {
              case 'surfaces':
                return <Home {...iconProps} />;
              case 'kitchen':
                return <UtensilsCrossed {...iconProps} />;
              case 'bathroom':
                return <Waves {...iconProps} />;
              case 'flooring':
                return <Broom {...iconProps} />;
            }
          };

          const categoryLabels: Record<ScopeCategory, string> = {
            surfaces: 'SURFACES',
            kitchen: 'KITCHEN',
            bathroom: 'BATHROOM',
            flooring: 'FLOORING',
          };

          const categoryOrder: ScopeCategory[] = ['surfaces', 'kitchen', 'bathroom', 'flooring'];

          return (
            <View>
              {categoryOrder.map((category) => {
                const items = categorized[category];
                if (!items || items.length === 0) return null;

                return (
                  <View key={category} style={{ marginBottom: spacing.lg }}>
                    <View style={[styles.row, { marginBottom: spacing.sm, gap: spacing.sm }]}>
                      {getCategoryIcon(category)}
                      <Text
                        style={{
                          fontWeight: typography.weight.semibold,
                          fontSize: typography.size.sm,
                          color: colors.textPrimary,
                          letterSpacing: 0.5,
                        }}>
                        {categoryLabels[category]}
                      </Text>
                    </View>
                    <View style={{ gap: spacing.sm, paddingLeft: spacing.md }}>
                      {items.map((line: string) => {
                        const getItemIcon = () => {
                          const lower = line.toLowerCase();
                          if (
                            lower.includes('dust') ||
                            lower.includes('polish') ||
                            lower.includes('straightening')
                          )
                            return <Sparkles size={16} color={colors.success} />;
                          if (lower.includes('scrub') || lower.includes('degrease'))
                            return <Wind size={16} color={colors.success} />;
                          if (lower.includes('sanitiz') || lower.includes('chrome') || lower.includes('water'))
                            return <Droplets size={16} color={colors.success} />;
                          if (lower.includes('vacuuming') || lower.includes('mopping'))
                            return <Broom size={16} color={colors.success} />;
                          return <Sparkles size={16} color={colors.success} />;
                        };
                        return (
                          <View key={line} style={[styles.scopeRow, { alignItems: 'flex-start' }]}>
                            {getItemIcon()}
                            <Text style={{ flex: 1, marginLeft: spacing.sm, color: colors.textSecondary }}>
                              {line}
                            </Text>
                          </View>
                        );
                      })}
                    </View>
                  </View>
                );
              })}
            </View>
          );
        })()}

        <View style={{ marginTop: spacing.lg }}>
          <Badge label="🌿 Plant-based, pet-safe kit included" tone="success" />
        </View>
      </ScrollView>

      <View
        style={[styles.footer, { backgroundColor: colors.surface, borderTopColor: colors.border, padding: spacing.lg }]}>
        <View>
          <Text style={{ color: colors.textSecondary, fontSize: typography.size.xs }}>Total</Text>
          <Text
            style={{ fontSize: typography.size.xl, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
            ₹{service.priceInr}
          </Text>
        </View>
        <View style={{ flex: 1, marginLeft: spacing.lg }}>
          <Button
            label="Schedule"
            onPress={() => {
              setDraft({ serviceId: service.id, mode: 'scheduled', addOnIds: [] });
              router.push('/booking/address');
            }}
          />
        </View>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  row: { flexDirection: 'row', alignItems: 'center', flexWrap: 'wrap' },
  scopeRow: { flexDirection: 'row', alignItems: 'flex-start' },
  footer: { flexDirection: 'row', alignItems: 'center', borderTopWidth: 1 },
});
