import { Stack } from 'expo-router';
import { CheckCircle2 } from 'lucide-react-native';
import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Button } from '@/src/components/Button';
import { Screen } from '@/src/components/Screen';
import { paletteList } from '@/src/theme/palettes';
import { useTheme } from '@/src/theme/useTheme';
import { useBrandStore } from '@/src/store/brandStore';

export default function BrandingScreen() {
  const { colors, spacing, typography, radii } = useTheme();
  const appName = useBrandStore((s) => s.appName);
  const paletteId = useBrandStore((s) => s.paletteId);
  const setAppName = useBrandStore((s) => s.setAppName);
  const setPaletteId = useBrandStore((s) => s.setPaletteId);
  const [draftName, setDraftName] = useState(appName);

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: 'Branding & Appearance', headerShown: true }} />
      <ScrollView contentContainerStyle={{ padding: spacing.lg }}>
        <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary, marginBottom: spacing.sm }}>
          App name
        </Text>
        <TextInput
          value={draftName}
          onChangeText={setDraftName}
          placeholder="Enter app name"
          placeholderTextColor={colors.textSecondary}
          style={[
            styles.input,
            {
              borderColor: colors.border,
              borderRadius: radii.md,
              padding: spacing.md,
              color: colors.textPrimary,
              backgroundColor: colors.surface,
            },
          ]}
        />
        <View style={{ marginTop: spacing.sm }}>
          <Button
            label="Save name"
            variant="secondary"
            onPress={() => setAppName(draftName.trim() || 'PureNest')}
          />
        </View>

        <Text
          style={{
            fontWeight: typography.weight.semibold,
            color: colors.textPrimary,
            marginTop: spacing.xl,
            marginBottom: spacing.sm,
          }}>
          Color palette
        </Text>
        <View style={{ gap: spacing.sm }}>
          {paletteList.map((palette) => (
            <Pressable
              key={palette.id}
              onPress={() => setPaletteId(palette.id)}
              style={[
                styles.paletteRow,
                {
                  borderRadius: radii.lg,
                  borderColor: palette.id === paletteId ? palette.colors.primary : colors.border,
                  backgroundColor: colors.surface,
                  padding: spacing.md,
                },
              ]}>
              <View style={styles.swatchGroup}>
                <View style={[styles.swatch, { backgroundColor: palette.colors.primary }]} />
                <View style={[styles.swatch, { backgroundColor: palette.colors.accent }]} />
                <View
                  style={[
                    styles.swatch,
                    { backgroundColor: palette.colors.background, borderWidth: 1, borderColor: colors.border },
                  ]}
                />
              </View>
              <View style={{ marginLeft: spacing.md, flex: 1 }}>
                <Text style={{ color: colors.textPrimary, fontWeight: '600' }}>{palette.name}</Text>
                <Text style={{ color: colors.textMuted, fontSize: 12, marginTop: 2 }}>{palette.subtitle}</Text>
              </View>
              {palette.id === paletteId ? (
                <CheckCircle2 size={20} color={palette.colors.primary} />
              ) : null}
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  input: { borderWidth: 1 },
  paletteRow: { flexDirection: 'row', alignItems: 'center', borderWidth: 1.5 },
  swatchGroup: { flexDirection: 'row' },
  swatch: { width: 20, height: 20, borderRadius: 10, marginRight: -6 },
});
