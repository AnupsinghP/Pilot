import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack } from 'expo-router';
import { Camera, CircleDollarSign, ClipboardCheck, ShieldCheck } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { useTheme } from '@/src/theme/useTheme';

const COVERAGE = [
  {
    Icon: ClipboardCheck,
    title: 'Photo-verified checklist',
    body: 'Every visit is checked off room-by-room with before/after photo proof from your professional.',
  },
  {
    Icon: Camera,
    title: '48-hour inspection window',
    body: 'Notice an issue after the clean? Report it within 48 hours for a free re-clean or repair.',
  },
  {
    Icon: CircleDollarSign,
    title: 'Damage reimbursement',
    body: 'Accidental damage caused during a booking is covered up to ₹25,000 per visit.',
  },
];

export default function DamageProtectionScreen() {
  const { colors, hero, radii, spacing, typography, fonts, shadow } = useTheme();

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: 'Damage Protection', headerShown: true }} />
      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
        <View style={[styles.hero, { backgroundColor: hero.background, borderRadius: radii.xl }]}>
          <ShieldCheck size={28} color="#FFFFFF" />
          <Text style={{ marginTop: spacing.sm, color: hero.text, fontSize: 20, fontFamily: fonts.headingSemiBold }}>
            100% Damage Protection Guarantee
          </Text>
          <Text style={{ marginTop: spacing.xs, color: hero.textMuted, fontSize: typography.size.sm }}>
            Every booking is backed by our guarantee — clean with confidence.
          </Text>
        </View>

        <View style={{ marginTop: spacing.xl, gap: spacing.sm }}>
          {COVERAGE.map((item) => (
            <View
              key={item.title}
              style={[
                styles.card,
                shadow.card,
                { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md },
              ]}>
              <View style={[styles.iconWrap, { backgroundColor: colors.primaryMuted }]}>
                <item.Icon size={18} color={colors.primary} />
              </View>
              <View style={{ marginLeft: spacing.md, flex: 1 }}>
                <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
                  {item.title}
                </Text>
                <Text style={{ marginTop: 2, color: colors.textSecondary, fontSize: typography.size.sm }}>
                  {item.body}
                </Text>
              </View>
            </View>
          ))}
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  hero: { padding: 20 },
  card: { flexDirection: 'row', alignItems: 'flex-start' },
  iconWrap: { width: 36, height: 36, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
});
