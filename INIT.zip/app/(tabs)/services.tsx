import { useRouter } from 'expo-router';
import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { CoreServiceCard } from '@/src/components/CoreServiceCard';
import { Screen } from '@/src/components/Screen';
import { services } from '@/src/data/services';
import { useTheme } from '@/src/theme/useTheme';

export default function ServicesScreen() {
  const router = useRouter();
  const { colors, spacing, fonts } = useTheme();

  return (
    <Screen edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
        <Text style={{ fontSize: 22, fontFamily: fonts.headingSemiBold, color: colors.textPrimary }}>
          Services
        </Text>
        <Text style={{ marginTop: 4, color: colors.textSecondary }}>
          Flat, transparent rates. Choose a cleaning journey to see full details.
        </Text>

        <View style={[styles.grid, { marginTop: spacing.lg }]}>
          {services.map((service, i) => (
            <CoreServiceCard
              key={service.id}
              service={service}
              index={i}
              onPress={() => router.push({ pathname: '/service/[id]', params: { id: service.id } })}
            />
          ))}
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
});
