import React from 'react';
import { Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { Activity } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Button } from '@/src/components/Button';
import { LiveTracking } from '@/src/components/LiveTracking';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

export default function LiveCleanTab() {
  const router = useRouter();
  const { colors, spacing, typography } = useTheme();
  const bookings = useBookingStore((s) => s.bookings);

  // Prefer an in-progress clean, otherwise the next upcoming one.
  const activeBooking =
    bookings.find((b) => b.status === 'in_progress') ?? bookings.find((b) => b.status === 'upcoming');

  if (!activeBooking) {
    return (
      <Screen edges={['top']}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl }}>
          <Activity size={48} color={colors.textSecondary} />
          <Text
            style={{
              marginTop: spacing.md,
              fontSize: typography.size.lg,
              fontWeight: typography.weight.semibold,
              color: colors.textPrimary,
            }}>
            No active clean right now
          </Text>
          <Text style={{ marginTop: spacing.xs, textAlign: 'center', color: colors.textSecondary }}>
            Book a service and this tab will show real-time progress, photo milestones, and cleaner chat.
          </Text>
          <View style={{ marginTop: spacing.lg, alignSelf: 'stretch' }}>
            <Button label="Book a cleaning" onPress={() => router.push('/(tabs)')} />
          </View>
        </View>
      </Screen>
    );
  }

  return (
    <Screen edges={['top']}>
      <LiveTracking booking={activeBooking} />
    </Screen>
  );
}
