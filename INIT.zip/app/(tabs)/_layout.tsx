import { Tabs } from 'expo-router';
import { Activity, CalendarClock, Leaf, ShieldCheck, Sparkles } from 'lucide-react-native';
import { ColorValue, View } from 'react-native';
import { useTheme } from '@/src/theme/useTheme';

function TabIcon({
  Icon,
  focused,
  color,
  hero,
  dot,
}: {
  Icon: any;
  focused: boolean;
  color: ColorValue;
  hero: string;
  dot?: boolean;
}) {
  return (
    <View
      style={{
        width: 36,
        height: 30,
        borderRadius: 16,
        alignItems: 'center',
        justifyContent: 'center',
        backgroundColor: focused ? hero : 'transparent',
      }}>
      <Icon size={18} color={focused ? '#FFFFFF' : color} />
      {dot ? (
        <View
          style={{
            position: 'absolute',
            top: 2,
            right: 6,
            width: 7,
            height: 7,
            borderRadius: 4,
            backgroundColor: '#10B981',
            borderWidth: 1.5,
            borderColor: focused ? hero : '#FFFFFF',
          }}
        />
      ) : null}
    </View>
  );
}

export default function TabLayout() {
  const { colors, hero } = useTheme();

  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        tabBarActiveTintColor: colors.textPrimary,
        tabBarInactiveTintColor: colors.textSecondary,
        tabBarLabelStyle: { fontSize: 11, fontWeight: '500' },
        tabBarStyle: {
          backgroundColor: colors.surface,
          borderTopColor: colors.border,
          height: 64,
          paddingTop: 8,
          paddingBottom: 10,
        },
      }}>
      <Tabs.Screen
        name="index"
        options={{
          title: 'Explore',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon Icon={Sparkles} focused={focused} color={color} hero={hero.background} />
          ),
        }}
      />
      <Tabs.Screen
        name="moveout"
        options={{
          title: 'Move-Out',
          tabBarBadge: 'Guarantee',
          tabBarBadgeStyle: { backgroundColor: colors.success, fontSize: 8, transform: [{ scale: 0.85 }] },
          tabBarIcon: ({ color, focused }) => (
            <TabIcon Icon={ShieldCheck} focused={focused} color={color} hero={hero.background} />
          ),
        }}
      />
      <Tabs.Screen
        name="seasonal"
        options={{
          title: 'Seasonal',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon Icon={Leaf} focused={focused} color={color} hero={hero.background} />
          ),
        }}
      />
      <Tabs.Screen
        name="subscription"
        options={{
          title: 'Plans',
          tabBarBadge: '-20%',
          tabBarBadgeStyle: { backgroundColor: colors.primary, fontSize: 8, transform: [{ scale: 0.85 }] },
          tabBarIcon: ({ color, focused }) => (
            <TabIcon Icon={CalendarClock} focused={focused} color={color} hero={hero.background} />
          ),
        }}
      />
      <Tabs.Screen
        name="tracker"
        options={{
          title: 'Live Clean',
          tabBarIcon: ({ color, focused }) => (
            <TabIcon Icon={Activity} focused={focused} color={color} hero={hero.background} dot />
          ),
        }}
      />
      {/* Kept as reachable routes (service catalog, past bookings, profile) but not shown as top-level tabs. */}
      <Tabs.Screen name="services" options={{ href: null }} />
      <Tabs.Screen name="bookings" options={{ href: null }} />
      <Tabs.Screen name="profile" options={{ href: null }} />
    </Tabs>
  );
}

