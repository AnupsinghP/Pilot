import React from 'react';
import { Screen } from '@/src/components/Screen';
import { MoveOutDetail } from '@/src/components/MoveOutDetail';
import { getServiceById } from '@/src/data/services';

const MOVE_OUT_SERVICE = getServiceById('move-out-deep')!;

export default function MoveOutTab() {
  return (
    <Screen edges={['top']}>
      <MoveOutDetail service={MOVE_OUT_SERVICE} />
    </Screen>
  );
}
