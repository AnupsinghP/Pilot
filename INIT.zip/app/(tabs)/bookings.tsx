import React from 'react';
import { FlatList, Pressable, Text, View } from 'react-native';
import { useRouter } from 'expo-router';
import { CalendarClock, ChevronRight } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Badge } from '@/src/components/Badge';
import { getServiceById } from '@/src/data/services';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

const STATUS_TONE = {
  upcoming: 'primary',
  in_progress: 'warning',
  completed: 'success',
  cancelled: 'neutral',
} as const;

const STATUS_LABEL = {
  upcoming: 'Upcoming',
  in_progress: 'In progress',
  completed: 'Completed',
  cancelled: 'Cancelled',
} as const;

export default function BookingsScreen() {
  const router = useRouter();
  const { colors, radii, spacing, typography, shadow } = useTheme();
  const bookings = useBookingStore((s) => s.bookings);

  const empty = {
    Icon: CalendarClock,
    title: 'No bookings yet',
    body: 'Your upcoming and past cleaning bookings will show up here.',
  };

  if (bookings.length === 0) {
    return (
      <Screen>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl }}>
          <empty.Icon size={48} color={colors.textSecondary} />
          <Text
            style={{
              marginTop: spacing.md,
              fontSize: typography.size.lg,
              fontWeight: typography.weight.semibold,
              color: colors.textPrimary,
            }}>
            {empty.title}
          </Text>
          <Text style={{ marginTop: spacing.xs, textAlign: 'center', color: colors.textSecondary }}>
            {empty.body}
          </Text>
        </View>
      </Screen>
    );
  }

  return (
    <Screen>
      <FlatList
        data={bookings}
        keyExtractor={(b) => b.id}
        contentContainerStyle={{ padding: spacing.lg, gap: spacing.md }}
        renderItem={({ item }) => {
          const service = getServiceById(item.serviceId);
          return (
            <Pressable
              onPress={() => router.push({ pathname: '/booking/[id]/tracking', params: { id: item.id } })}
              style={[
                shadow.card,
                {
                  flexDirection: 'row',
                  alignItems: 'center',
                  backgroundColor: colors.surface,
                  borderRadius: radii.lg,
                  padding: spacing.md,
                },
              ]}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
                  {service?.name ?? 'Service'}
                </Text>
                <Text style={{ marginTop: 2, fontSize: typography.size.xs, color: colors.textSecondary }}>
                  {new Date(item.createdAt).toLocaleDateString()} · ₹{item.totalPriceInr}
                </Text>
                <View style={{ marginTop: 6, alignSelf: 'flex-start' }}>
                  <Badge label={STATUS_LABEL[item.status]} tone={STATUS_TONE[item.status]} />
                </View>
              </View>
              <ChevronRight size={18} color={colors.textSecondary} />
            </Pressable>
          );
        }}
      />
    </Screen>
  );
}
