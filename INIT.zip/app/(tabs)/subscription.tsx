import React, { useState } from 'react';
import { Alert, Pressable, ScrollView, Text, View } from 'react-native';
import { CalendarClock } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Avatar } from '@/src/components/Avatar';
import { Badge } from '@/src/components/Badge';
import { Button } from '@/src/components/Button';
import { professionals } from '@/src/data/professionals';
import { subscriptionPlans } from '@/src/data/subscriptionPlans';
import { useTheme } from '@/src/theme/useTheme';

const PRIMARY_CLEANER = professionals[0]; // Priya Sharma

export default function SubscriptionTab() {
  const { colors, radii, spacing, typography, shadow, fonts } = useTheme();
  const [activePlanId, setActivePlanId] = useState<string | null>(null);

  return (
    <Screen edges={['top']}>
      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
        <View style={{ flexDirection: 'row', alignItems: 'center', gap: 6 }}>
          <CalendarClock size={16} color={colors.primary} />
          <Text style={{ fontSize: typography.size.xs, fontWeight: typography.weight.semibold, color: colors.primary }}>
            Carefree Home Membership
          </Text>
        </View>
        <Text style={{ marginTop: spacing.xs, fontSize: 22, fontFamily: fonts.headingSemiBold, color: colors.textPrimary }}>
          Recurring Cleaning Club
        </Text>
        <Text style={{ marginTop: 2, color: colors.textSecondary, fontSize: typography.size.sm }}>
          Keep your home consistently spotless. Lock in up to 25% off and the same trusted cleaner for every visit.
        </Text>

        <View style={{ marginTop: spacing.lg, gap: spacing.md }}>
          {subscriptionPlans.map((plan) => {
            const isActive = activePlanId === plan.id;
            return (
              <View
                key={plan.id}
                style={[
                  shadow.card,
                  {
                    backgroundColor: colors.surface,
                    borderRadius: radii.lg,
                    padding: spacing.md,
                    borderWidth: plan.mostPopular ? 1.5 : 0,
                    borderColor: colors.primary,
                  },
                ]}>
                <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
                  <View style={{ flexDirection: 'row', alignItems: 'center', gap: 8 }}>
                    <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
                      {plan.name}
                    </Text>
                    {plan.mostPopular ? <Badge label="Most popular" tone="primary" /> : null}
                  </View>
                  <Badge label={plan.discountLabel} tone="success" />
                </View>
                <Text style={{ marginTop: 2, fontSize: typography.size.xs, color: colors.textSecondary }}>
                  Billed per visit · No commitments
                </Text>
                <View style={{ flexDirection: 'row', alignItems: 'baseline', marginTop: spacing.sm }}>
                  <Text
                    style={{ fontSize: typography.size.xl, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
                    ₹{plan.pricePerCleanInr}
                  </Text>
                  <Text
                    style={{
                      marginLeft: 6,
                      fontSize: typography.size.xs,
                      color: colors.textSecondary,
                      textDecorationLine: 'line-through',
                    }}>
                    ₹{plan.originalPriceInr}
                  </Text>
                  <Text style={{ marginLeft: 6, fontSize: typography.size.xs, color: colors.textSecondary }}>
                    /clean
                  </Text>
                </View>
                <View style={{ marginTop: spacing.sm, gap: 4 }}>
                  {plan.perks.map((perk) => (
                    <Text key={perk} style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>
                      ✓ {perk}
                    </Text>
                  ))}
                </View>
                <View style={{ marginTop: spacing.md }}>
                  <Button
                    label={isActive ? 'Activated' : `Activate Plan (₹${plan.pricePerCleanInr}/clean)`}
                    variant={isActive ? 'secondary' : 'primary'}
                    onPress={() => setActivePlanId(plan.id)}
                  />
                </View>
              </View>
            );
          })}
        </View>

        <View
          style={[
            shadow.card,
            {
              marginTop: spacing.xl,
              backgroundColor: colors.surface,
              borderRadius: radii.lg,
              padding: spacing.md,
            },
          ]}>
          <View style={{ flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' }}>
            <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
              Your Dedicated Primary Cleaner
            </Text>
            <Badge label="Guaranteed Match" tone="success" />
          </View>
          <Text style={{ marginTop: 2, fontSize: typography.size.xs, color: colors.textSecondary }}>
            Never worry about rotating strangers. Your primary pro learns your home's unique nuances.
          </Text>
          <View style={{ flexDirection: 'row', alignItems: 'center', marginTop: spacing.md }}>
            <Avatar uri={PRIMARY_CLEANER.avatarUrl} name={PRIMARY_CLEANER.name} size={48} />
            <View style={{ marginLeft: spacing.md, flex: 1 }}>
              <Text style={{ fontWeight: typography.weight.medium, color: colors.textPrimary }}>
                {PRIMARY_CLEANER.name}
              </Text>
              <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>
                ⭐ {PRIMARY_CLEANER.rating}
              </Text>
            </View>
            <Pressable
              onPress={() => Alert.alert('Switch cleaner', 'Browsing other top-rated pros in your area (mock).')}>
              <Text style={{ color: colors.primary, fontWeight: typography.weight.semibold }}>Switch</Text>
            </Pressable>
          </View>
        </View>
      </ScrollView>
    </Screen>
  );
}
