import React from 'react';
import { Screen } from '@/src/components/Screen';
import { SeasonalDetail } from '@/src/components/SeasonalDetail';
import { getServiceById } from '@/src/data/services';

const SEASONAL_SERVICE = getServiceById('seasonal-revive')!;

export default function SeasonalTab() {
  return (
    <Screen edges={['top']}>
      <SeasonalDetail service={SEASONAL_SERVICE} />
    </Screen>
  );
}
