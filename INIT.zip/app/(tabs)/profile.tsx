import { useRouter } from 'expo-router';
import { ChevronRight, CreditCard, Gift, HelpCircle, MapPin, Palette, ShieldCheck } from 'lucide-react-native';
import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Avatar } from '@/src/components/Avatar';
import { Screen } from '@/src/components/Screen';
import { useBrandStore } from '@/src/store/brandStore';
import { useTheme } from '@/src/theme/useTheme';

const MENU_ITEMS = [
  { Icon: MapPin, label: 'Saved addresses' },
  { Icon: CreditCard, label: 'Payment methods' },
  { Icon: ShieldCheck, label: 'Trust & Safety' },
  { Icon: HelpCircle, label: 'Help & FAQ' },
  { Icon: Gift, label: 'Refer & earn' },
] as const;

export default function ProfileScreen() {
  const router = useRouter();
  const { colors, spacing, typography, radii } = useTheme();
  const appName = useBrandStore((s) => s.appName);

  return (
    <Screen>
      <ScrollView contentContainerStyle={{ padding: spacing.lg }}>
        <View
          style={[
            styles.headerCard,
            { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.lg },
          ]}>
          <Avatar name="You" size={56} />
          <View style={{ marginLeft: spacing.md }}>
            <Text
              style={{
                fontWeight: typography.weight.semibold,
                fontSize: typography.size.lg,
                color: colors.textPrimary,
              }}>
              Welcome
            </Text>
            <Text style={{ color: colors.textSecondary, fontSize: typography.size.sm }}>Using {appName}</Text>
          </View>
        </View>

        <Pressable
          onPress={() => router.push('/settings/branding')}
          style={[
            styles.menuItem,
            { backgroundColor: colors.surface, borderRadius: radii.lg, marginTop: spacing.lg, padding: spacing.md },
          ]}>
          <Palette size={20} color={colors.primary} />
          <Text style={{ marginLeft: spacing.md, flex: 1, color: colors.textPrimary }}>Branding & Appearance</Text>
          <ChevronRight size={18} color={colors.textSecondary} />
        </Pressable>

        <View style={{ marginTop: spacing.md, gap: spacing.sm }}>
          {MENU_ITEMS.map((item) => (
            <Pressable
              key={item.label}
              style={[styles.menuItem, { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md }]}>
              <item.Icon size={20} color={colors.primary} />
              <Text style={{ marginLeft: spacing.md, flex: 1, color: colors.textPrimary }}>{item.label}</Text>
              <ChevronRight size={18} color={colors.textSecondary} />
            </Pressable>
          ))}
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  headerCard: { flexDirection: 'row', alignItems: 'center' },
  menuItem: { flexDirection: 'row', alignItems: 'center' },
});
