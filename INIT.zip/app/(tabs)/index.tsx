import { useRouter } from 'expo-router';
import { Bell, MapPin, Search } from 'lucide-react-native';
import React from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { CoreServiceCard } from '@/src/components/CoreServiceCard';
import { RoomCustomizer } from '@/src/components/RoomCustomizer';
import { Screen } from '@/src/components/Screen';
import { SectionHeader } from '@/src/components/SectionHeader';
import { ServiceCard } from '@/src/components/ServiceCard';
import { SummaryCard } from '@/src/components/SummaryCard';
import { TrustPill } from '@/src/components/TrustPill';
import { recentServiceIds } from '@/src/data/recentActivity';
import { getServiceById, services } from '@/src/data/services';
import { useBrandStore } from '@/src/store/brandStore';
import { useTheme } from '@/src/theme/useTheme';

export default function HomeScreen() {
  const router = useRouter();
  const { colors, hero, spacing, radii, typography, shadow, fonts } = useTheme();
  const appName = useBrandStore((s) => s.appName);
  const recentServices = recentServiceIds.map(getServiceById).filter((s): s is NonNullable<typeof s> => !!s);

  return (
    <Screen>
      <ScrollView
        contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}
        showsVerticalScrollIndicator={false}>
        <View style={styles.headerRow}>
          <View>
            <View style={styles.locationRow}>
              <MapPin size={14} color={colors.primary} />
              <Text style={{ marginLeft: 4, color: colors.textSecondary, fontSize: typography.size.xs }}>
                Home · Koramangala
              </Text>
            </View>
            <Text
              style={{
                marginTop: 2,
                fontSize: typography.size.xxl,
                fontFamily: fonts.headingSemiBold,
                color: colors.textPrimary,
              }}>
              {appName}
            </Text>
          </View>
          <Pressable
            style={[styles.bellButton, { backgroundColor: colors.surface, ...shadow.card }]}
            hitSlop={8}>
            <Bell size={20} color={colors.textPrimary} />
          </Pressable>
        </View>

        <Pressable
          style={[
            styles.searchBar,
            { backgroundColor: colors.surface, borderRadius: radii.lg, marginTop: spacing.lg, ...shadow.card },
          ]}>
          <Search size={18} color={colors.textSecondary} />
          <Text style={{ marginLeft: spacing.sm, color: colors.textSecondary, fontSize: typography.size.sm }}>
            Search "kitchen deep clean"
          </Text>
        </Pressable>

        <View
          style={[styles.hero, { backgroundColor: hero.background, borderRadius: radii.xl, marginTop: spacing.lg }]}>
          <View
            style={[
              styles.heroTag,
              { backgroundColor: 'rgba(255,255,255,0.12)', borderRadius: radii.pill, marginBottom: spacing.md },
            ]}>
            <View style={[styles.heroDot, { backgroundColor: '#8FD19E' }]} />
            <Text style={{ color: hero.text, fontSize: 11, fontWeight: typography.weight.medium }}>
              Style: {appName}
            </Text>
          </View>
          <Text style={{ color: hero.text, fontSize: 26, fontFamily: fonts.headingSemiBold, lineHeight: 32 }}>
            Pristine spaces,{'\n'}tailored to your routine.
          </Text>
          <Text style={{ color: hero.textMuted, marginTop: spacing.sm, fontSize: typography.size.sm, lineHeight: 20 }}>
            Move-out deposit guarantees, seasonal refreshes, and seamless cleaner subscriptions.
          </Text>
          <View style={styles.trustRow}>
            <TrustPill label="Vetted & Insured" />
            <TrustPill label="Plant-Based Kit" />
          </View>
        </View>

        <View style={{ height: spacing.xl }} />
        <SectionHeader title="Select cleaning experience" eyebrow actionLabel="Flat transparent rates" />
        <View style={styles.grid}>
          {services.map((service, i) => (
            <CoreServiceCard
              key={service.id}
              service={service}
              index={i}
              onPress={() => router.push({ pathname: '/service/[id]', params: { id: service.id } })}
            />
          ))}
        </View>

        <RoomCustomizer />

        <View style={{ height: spacing.lg }} />
        <SummaryCard
          title="Recurring Club — Bi-Weekly or Monthly"
          subtitle="Save 20% & lock in your favorite dedicated cleaner"
          previewIcons={['calendar-refresh', 'account-heart-outline', 'sale-outline', 'shield-star-outline']}
          onPress={() => router.push({ pathname: '/(tabs)/bookings', params: { tab: 'plans' } })}
        />

        {recentServices.length > 0 ? (
          <>
            <View style={{ height: spacing.xl }} />
            <SectionHeader title="Book again" />
            <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginHorizontal: -spacing.lg }}>
              <View style={{ flexDirection: 'row', paddingHorizontal: spacing.lg, gap: spacing.md }}>
                {recentServices.map((service) => (
                  <View key={service.id} style={{ width: 220 }}>
                    <ServiceCard
                      service={service}
                      onPress={() => router.push({ pathname: '/service/[id]', params: { id: service.id } })}
                    />
                  </View>
                ))}
              </View>
            </ScrollView>
          </>
        ) : null}
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  headerRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  locationRow: { flexDirection: 'row', alignItems: 'center' },
  bellButton: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
  searchBar: { flexDirection: 'row', alignItems: 'center', padding: 14 },
  hero: { padding: 20 },
  heroTag: {
    flexDirection: 'row',
    alignItems: 'center',
    alignSelf: 'flex-start',
    paddingHorizontal: 10,
    paddingVertical: 5,
  },
  heroDot: { width: 6, height: 6, borderRadius: 3, marginRight: 6 },
  trustRow: { flexDirection: 'row', flexWrap: 'wrap', marginTop: 4 },
  grid: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'space-between' },
});
