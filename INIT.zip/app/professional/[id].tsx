import React, { useEffect, useState } from 'react';
import { ActivityIndicator, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack, useLocalSearchParams } from 'expo-router';
import { Award, BadgeCheck, Languages, ShieldCheck } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Avatar } from '@/src/components/Avatar';
import { Badge } from '@/src/components/Badge';
import { Professional } from '@/src/data/professionals';
import { fetchProfessional } from '@/src/services/professionalRepository';
import { useTheme } from '@/src/theme/useTheme';

const RATING_BREAKDOWN = [
  { stars: 5, pct: 78 },
  { stars: 4, pct: 15 },
  { stars: 3, pct: 5 },
  { stars: 2, pct: 1 },
  { stars: 1, pct: 1 },
];

export default function ProfessionalProfileScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { colors, radii, spacing, typography, fonts, shadow } = useTheme();
  const [professional, setProfessional] = useState<Professional>();

  useEffect(() => {
    fetchProfessional(id).then(setProfessional);
  }, [id]);

  if (!professional) {
    return (
      <Screen>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center' }}>
          <ActivityIndicator color={colors.primary} />
        </View>
      </Screen>
    );
  }

  const trustItems = [
    { Icon: BadgeCheck, label: 'Government ID verified', met: professional.idVerified },
    { Icon: ShieldCheck, label: 'Background check passed', met: professional.backgroundCheckPassed },
    { Icon: Award, label: 'Training certified', met: professional.trainingCertified },
  ];

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: professional.name, headerShown: true }} />
      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
        <View style={styles.header}>
          <Avatar uri={professional.avatarUrl} name={professional.name} size={80} />
          <Text style={{ marginTop: spacing.md, fontSize: 20, fontFamily: fonts.headingSemiBold, color: colors.textPrimary }}>
            {professional.name}
          </Text>
          <Text style={{ marginTop: 2, color: colors.textSecondary, fontSize: typography.size.sm }}>
            ⭐ {professional.rating} · {professional.completedJobs} jobs · {professional.yearsExperience} yrs experience
          </Text>
          <Text style={{ marginTop: spacing.sm, color: colors.textSecondary, textAlign: 'center' }}>
            {professional.bio}
          </Text>
          <View style={[styles.row, { marginTop: spacing.sm, gap: 6 }]}>
            <Languages size={14} color={colors.textSecondary} />
            <Text style={{ color: colors.textSecondary, fontSize: typography.size.xs }}>
              {professional.languages.join(', ')}
            </Text>
          </View>
        </View>

        <Text style={{ marginTop: spacing.xl, marginBottom: spacing.sm, fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
          Verification & trust
        </Text>
        <View style={{ gap: spacing.sm }}>
          {trustItems.map((item) => (
            <View
              key={item.label}
              style={[
                styles.trustRow,
                shadow.card,
                { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md },
              ]}>
              <item.Icon size={18} color={item.met ? colors.success : colors.textSecondary} />
              <Text style={{ marginLeft: spacing.md, flex: 1, color: colors.textPrimary }}>{item.label}</Text>
              <Badge label={item.met ? 'Verified' : 'Pending'} tone={item.met ? 'success' : 'neutral'} />
            </View>
          ))}
        </View>

        <Text style={{ marginTop: spacing.xl, marginBottom: spacing.sm, fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
          Rating breakdown
        </Text>
        <View
          style={[
            shadow.card,
            { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md, gap: spacing.xs },
          ]}>
          {RATING_BREAKDOWN.map((row) => (
            <View key={row.stars} style={styles.ratingRow}>
              <Text style={{ width: 32, fontSize: typography.size.xs, color: colors.textSecondary }}>
                {row.stars}★
              </Text>
              <View style={[styles.barTrack, { backgroundColor: colors.surfaceSubtle, borderRadius: radii.pill }]}>
                <View
                  style={[
                    styles.barFill,
                    { width: `${row.pct}%`, backgroundColor: colors.warning, borderRadius: radii.pill },
                  ]}
                />
              </View>
              <Text style={{ width: 36, fontSize: typography.size.xs, color: colors.textSecondary, textAlign: 'right' }}>
                {row.pct}%
              </Text>
            </View>
          ))}
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  header: { alignItems: 'center' },
  row: { flexDirection: 'row', alignItems: 'center' },
  trustRow: { flexDirection: 'row', alignItems: 'center' },
  ratingRow: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  barTrack: { flex: 1, height: 6, overflow: 'hidden' },
  barFill: { height: 6 },
});
