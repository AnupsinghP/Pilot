import React from 'react';
import { Text, View } from 'react-native';
import { Stack, useLocalSearchParams } from 'expo-router';
import { Screen } from '@/src/components/Screen';
import { LiveTracking } from '@/src/components/LiveTracking';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

export default function TrackingScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { colors, spacing } = useTheme();
  const booking = useBookingStore((s) => s.getBooking(id));

  if (!booking) {
    return (
      <Screen edges={['top']}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl }}>
          <Text style={{ color: colors.textSecondary }}>Booking not found.</Text>
        </View>
      </Screen>
    );
  }

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: 'Live tracking', headerShown: true }} />
      <LiveTracking booking={booking} />
    </Screen>
  );
}
