import React, { useState } from 'react';
import { FlatList, KeyboardAvoidingView, Platform, Pressable, StyleSheet, Text, TextInput, View } from 'react-native';
import { Stack, useLocalSearchParams } from 'expo-router';
import { Send } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { useBookingStore } from '@/src/store/bookingStore';
import { fetchProfessional } from '@/src/services/professionalRepository';
import { Professional } from '@/src/data/professionals';
import { useTheme } from '@/src/theme/useTheme';

interface Message {
  id: string;
  from: 'me' | 'pro';
  text: string;
}

export default function ChatScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const { colors, radii, spacing } = useTheme();
  const booking = useBookingStore((s) => s.getBooking(id));
  const [professional, setProfessional] = useState<Professional>();
  const [input, setInput] = useState('');
  const [messages, setMessages] = useState<Message[]>([
    { id: 'm1', from: 'pro', text: "Hi! I'm on my way to your address. See you soon 😊" },
  ]);

  React.useEffect(() => {
    if (booking) fetchProfessional(booking.professionalId).then(setProfessional);
  }, [booking?.professionalId]);

  function send() {
    const text = input.trim();
    if (!text) return;
    const myMessage: Message = { id: `m-${Date.now()}`, from: 'me', text };
    setMessages((prev) => [...prev, myMessage]);
    setInput('');
    setTimeout(() => {
      setMessages((prev) => [
        ...prev,
        { id: `m-${Date.now()}-r`, from: 'pro', text: 'Got it, thank you for letting me know!' },
      ]);
    }, 1200);
  }

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: professional?.name ?? 'Chat', headerShown: true }} />
      <KeyboardAvoidingView style={{ flex: 1 }} behavior={Platform.OS === 'ios' ? 'padding' : undefined}>
        <FlatList
          data={messages}
          keyExtractor={(m) => m.id}
          contentContainerStyle={{ padding: spacing.lg, gap: spacing.sm }}
          renderItem={({ item }) => (
            <View
              style={[
                styles.bubble,
                {
                  alignSelf: item.from === 'me' ? 'flex-end' : 'flex-start',
                  backgroundColor: item.from === 'me' ? colors.primary : colors.surfaceSubtle,
                  borderRadius: radii.lg,
                  padding: spacing.md,
                },
              ]}>
              <Text style={{ color: item.from === 'me' ? colors.textOnPrimary : colors.textPrimary }}>
                {item.text}
              </Text>
            </View>
          )}
        />
        <View
          style={[
            styles.inputRow,
            { borderTopColor: colors.border, padding: spacing.md, backgroundColor: colors.surface },
          ]}>
          <TextInput
            value={input}
            onChangeText={setInput}
            placeholder="Type a message"
            placeholderTextColor={colors.textSecondary}
            style={[
              styles.input,
              { backgroundColor: colors.surfaceSubtle, borderRadius: radii.pill, color: colors.textPrimary },
            ]}
          />
          <Pressable
            onPress={send}
            style={[styles.sendButton, { backgroundColor: colors.primary, borderRadius: radii.pill }]}>
            <Send size={16} color={colors.textOnPrimary} />
          </Pressable>
        </View>
      </KeyboardAvoidingView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  bubble: { maxWidth: '80%' },
  inputRow: { flexDirection: 'row', alignItems: 'center', borderTopWidth: StyleSheet.hairlineWidth },
  input: { flex: 1, paddingHorizontal: 16, paddingVertical: 10, marginRight: 8 },
  sendButton: { width: 40, height: 40, alignItems: 'center', justifyContent: 'center' },
});
