import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { Star } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Button } from '@/src/components/Button';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

export default function ReviewScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { colors, spacing, radii, fonts } = useTheme();
  const addReview = useBookingStore((s) => s.addReview);
  const [rating, setRating] = useState(5);
  const [comment, setComment] = useState('');

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: 'Rate your experience', headerShown: true }} />
      <ScrollView contentContainerStyle={{ padding: spacing.lg, alignItems: 'center', paddingTop: spacing.xxl }}>
        <Text style={{ fontSize: 22, fontFamily: fonts.headingSemiBold, color: colors.textPrimary }}>
          How was the cleaning?
        </Text>
        <Text style={{ marginTop: spacing.xs, color: colors.textSecondary }}>Your feedback helps us improve.</Text>

        <View style={[styles.starsRow, { marginTop: spacing.xl }]}>
          {[1, 2, 3, 4, 5].map((n) => (
            <Pressable key={n} onPress={() => setRating(n)} hitSlop={8} style={{ marginHorizontal: 6 }}>
              <Star size={36} color={colors.warning} fill={n <= rating ? colors.warning : 'transparent'} />
            </Pressable>
          ))}
        </View>

        <TextInput
          value={comment}
          onChangeText={setComment}
          placeholder="Leave a comment (optional)"
          placeholderTextColor={colors.textSecondary}
          multiline
          numberOfLines={4}
          style={[
            styles.input,
            {
              width: '100%',
              marginTop: spacing.xl,
              borderColor: colors.border,
              borderRadius: radii.lg,
              padding: spacing.md,
              color: colors.textPrimary,
              backgroundColor: colors.surface,
            },
          ]}
        />

        <View style={{ width: '100%', marginTop: spacing.xl }}>
          <Button
            label="Submit review"
            onPress={() => {
              addReview(id, rating, comment.trim());
              router.replace('/(tabs)/bookings');
            }}
          />
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  starsRow: { flexDirection: 'row' },
  input: { borderWidth: 1, textAlignVertical: 'top', minHeight: 100 },
});
