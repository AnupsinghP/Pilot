import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, TextInput, View } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import {
  Banknote,
  Building2,
  CheckCircle2,
  CreditCard,
  Home as HomeIcon,
  KeyRound,
  Smartphone,
  Square,
  SquareCheck,
  Wallet,
} from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Button } from '@/src/components/Button';
import { Badge } from '@/src/components/Badge';
import { AccessMethod, accessMethods, arrivalSlots } from '@/src/data/arrivalSlots';
import { addOns, getAddOnById } from '@/src/data/addOns';
import { getAddressById } from '@/src/data/addresses';
import { paymentMethods } from '@/src/data/paymentMethods';
import { computeRoomPrice, getServiceById } from '@/src/data/services';
import { computeDraftTotal, useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

const PAYMENT_ICONS = { Smartphone, CreditCard, Wallet, Banknote } as const;
const ACCESS_ICONS = { lockbox: KeyRound, frontdesk: Building2, home: HomeIcon } as const;

export default function CheckoutScreen() {
  const router = useRouter();
  const { colors, radii, spacing, typography, fonts, shadow } = useTheme();
  const draft = useBookingStore((s) => s.draft);
  const setDraft = useBookingStore((s) => s.setDraft);
  const confirmBooking = useBookingStore((s) => s.confirmBooking);
  const service = draft.serviceId ? getServiceById(draft.serviceId) : undefined;
  const address = draft.addressId ? getAddressById(draft.addressId) : undefined;
  const defaultSlots = arrivalSlots.filter((slot) =>
    service ? (slot.mode === 'instant' ? service.instantAvailable : service.scheduledAvailable) : true
  );
  const defaultSlot = defaultSlots.find((s) => s.tag === 'Recommended') ?? defaultSlots[0];

  const [paymentId, setPaymentId] = useState(draft.paymentMethodId ?? paymentMethods[0].id);
  const [arrivalSlotId, setArrivalSlotId] = useState(draft.arrivalSlotId ?? defaultSlot?.id ?? '');
  const [accessMethod, setAccessMethod] = useState<AccessMethod>(draft.accessMethod ?? 'lockbox');
  const [lockboxCode, setLockboxCode] = useState(draft.lockboxCode ?? '');
  const [entryNotes, setEntryNotes] = useState(draft.entryNotes ?? '');
  const [submitting, setSubmitting] = useState(false);

  if (!service) {
    return (
      <Screen edges={['top']}>
        <Stack.Screen options={{ title: 'Checkout', headerShown: true }} />
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl }}>
          <Text style={{ color: colors.textSecondary }}>No service selected. Go back and pick a service.</Text>
        </View>
      </Screen>
    );
  }

  const availableSlots = defaultSlots;
  const roomPrice =
    service.roomCustomizable && draft.bedrooms && draft.bathrooms
      ? computeRoomPrice(service.priceInr, draft.bedrooms, draft.bathrooms)
      : service.priceInr;
  const total = computeDraftTotal(draft);
  const selectedAddOns = draft.addOnIds.map(getAddOnById).filter((a): a is NonNullable<typeof a> => !!a);

  function toggleAddOn(id: string) {
    const next = draft.addOnIds.includes(id)
      ? draft.addOnIds.filter((x) => x !== id)
      : [...draft.addOnIds, id];
    setDraft({ addOnIds: next });
  }

  async function handleConfirm() {
    const slot = arrivalSlots.find((s) => s.id === arrivalSlotId);
    setDraft({
      paymentMethodId: paymentId,
      arrivalSlotId: arrivalSlotId || undefined,
      mode: slot?.mode ?? draft.mode,
      accessMethod,
      lockboxCode: accessMethod === 'lockbox' ? lockboxCode.trim() || undefined : undefined,
      entryNotes: accessMethod === 'lockbox' ? entryNotes.trim() || undefined : undefined,
    });
    setSubmitting(true);
    const id = await confirmBooking();
    setSubmitting(false);
    router.replace({ pathname: '/booking/confirmation/[id]', params: { id } });
  }

  return (
    <Screen edges={['top']}>
      <Stack.Screen
        options={{
          headerShown: true,
          headerTitle: () => (
            <Text
              style={{
                fontSize: 13,
                fontWeight: '700',
                letterSpacing: 1,
                textTransform: 'uppercase',
                color: colors.textPrimary,
              }}>
              Complete Reservation
            </Text>
          ),
        }}
      />
      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
        <View
          style={[
            styles.summaryCard,
            shadow.card,
            { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md },
          ]}>
          <View style={styles.summaryHeaderRow}>
            <Badge label="One-Time Clean" tone="success" />
            <View style={{ alignItems: 'flex-end' }}>
              <Text style={{ fontSize: typography.size.lg, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
                ₹{total}
              </Text>
              <Text style={{ fontSize: 10, color: colors.textSecondary }}>Total</Text>
            </View>
          </View>
          <Text style={{ marginTop: spacing.sm, fontSize: typography.size.lg, fontFamily: fonts.headingSemiBold, color: colors.textPrimary }}>
            {service.name}
          </Text>
          <Text style={{ marginTop: 2, fontSize: typography.size.sm, color: colors.textSecondary }}>
            {draft.bedrooms && draft.bathrooms ? `${draft.bedrooms} Bed • ${draft.bathrooms} Bath • ` : ''}
            {address ? address.line1 : 'Select address'}
          </Text>
          {selectedAddOns.length > 0 ? (
            <View style={{ marginTop: spacing.sm }}>
              <Badge
                label={`+${selectedAddOns[0].name}${selectedAddOns.length > 1 ? ` +${selectedAddOns.length - 1} more` : ''}`}
              />
            </View>
          ) : null}
        </View>

        <Text
          style={{
            marginTop: spacing.xl,
            marginBottom: spacing.sm,
            fontSize: 12,
            fontWeight: typography.weight.semibold,
            color: colors.textSecondary,
            letterSpacing: 1,
            textTransform: 'uppercase',
          }}>
          Arrival Window
        </Text>
        <View style={{ gap: spacing.sm }}>
          {availableSlots.map((slot) => {
            const selected = slot.id === arrivalSlotId;
            return (
              <Pressable
                key={slot.id}
                onPress={() => setArrivalSlotId(slot.id)}
                style={[
                  styles.slotRow,
                  shadow.card,
                  {
                    backgroundColor: colors.surface,
                    borderRadius: radii.lg,
                    padding: spacing.md,
                    borderWidth: selected ? 1.5 : 0,
                    borderColor: colors.primary,
                  },
                ]}>
                <View style={{ flex: 1 }}>
                  <View style={styles.row}>
                    <Text style={{ color: colors.textPrimary, fontWeight: typography.weight.semibold }}>
                      {slot.label}
                    </Text>
                    {slot.tag ? (
                      <Badge label={slot.tag} tone={slot.tag === 'Fast' ? 'success' : 'primary'} />
                    ) : null}
                  </View>
                  <Text style={{ marginTop: 2, fontSize: typography.size.xs, color: colors.textSecondary }}>
                    {slot.timeRange}
                  </Text>
                </View>
                <View
                  style={[
                    styles.radioOuter,
                    { borderColor: selected ? colors.primary : colors.border },
                  ]}>
                  {selected ? <View style={[styles.radioInner, { backgroundColor: colors.primary }]} /> : null}
                </View>
              </Pressable>
            );
          })}
        </View>

        <View style={[styles.row, { marginTop: spacing.xl, marginBottom: spacing.sm, justifyContent: 'space-between' }]}>
          <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>Home Access Method</Text>
          <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary }}>Contactless Supported</Text>
        </View>
        <View style={styles.accessRow}>
          {accessMethods.map((method) => {
            const Icon = ACCESS_ICONS[method.id];
            const selected = accessMethod === method.id;
            return (
              <Pressable
                key={method.id}
                onPress={() => setAccessMethod(method.id)}
                style={[
                  styles.accessChip,
                  {
                    backgroundColor: colors.surface,
                    borderRadius: radii.md,
                    borderWidth: selected ? 1.5 : 1,
                    borderColor: selected ? colors.primary : colors.border,
                  },
                ]}>
                <Icon size={18} color={selected ? colors.primary : colors.textSecondary} />
                <Text
                  style={{
                    marginTop: 4,
                    fontSize: typography.size.xs,
                    textAlign: 'center',
                    fontWeight: typography.weight.medium,
                    color: selected ? colors.textPrimary : colors.textSecondary,
                  }}>
                  {method.label}
                </Text>
              </Pressable>
            );
          })}
        </View>

        {accessMethod === 'lockbox' ? (
          <View style={{ marginTop: spacing.md, gap: spacing.sm }}>
            <View>
              <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary, marginBottom: 4 }}>
                Lockbox Code / Digital Passcode
              </Text>
              <TextInput
                value={lockboxCode}
                onChangeText={setLockboxCode}
                placeholder="e.g. 4829"
                placeholderTextColor={colors.textSecondary}
                style={[
                  styles.input,
                  { borderColor: colors.border, borderRadius: radii.md, color: colors.textPrimary, backgroundColor: colors.surface },
                ]}
              />
            </View>
            <View>
              <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary, marginBottom: 4 }}>
                Entry Location Notes
              </Text>
              <TextInput
                value={entryNotes}
                onChangeText={setEntryNotes}
                placeholder="e.g. Lockbox is on the railing to the left of the front door"
                placeholderTextColor={colors.textSecondary}
                style={[
                  styles.input,
                  { borderColor: colors.border, borderRadius: radii.md, color: colors.textPrimary, backgroundColor: colors.surface },
                ]}
              />
            </View>
          </View>
        ) : null}

        <Text
          style={{
            marginTop: spacing.xl,
            marginBottom: spacing.sm,
            fontWeight: typography.weight.semibold,
            color: colors.textPrimary,
          }}>
          Add-ons
        </Text>
        <View style={{ gap: spacing.sm }}>
          {addOns.map((addOn) => {
            const selected = draft.addOnIds.includes(addOn.id);
            const CheckboxIcon = selected ? SquareCheck : Square;
            return (
              <Pressable
                key={addOn.id}
                onPress={() => toggleAddOn(addOn.id)}
                style={[
                  styles.addOnRow,
                  { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.md },
                ]}>
                <CheckboxIcon size={20} color={selected ? colors.primary : colors.textSecondary} />
                <View style={{ marginLeft: spacing.md, flex: 1 }}>
                  <Text style={{ color: colors.textPrimary, fontWeight: typography.weight.medium }}>
                    {addOn.name}
                  </Text>
                  <Text style={{ marginTop: 2, fontSize: typography.size.xs, color: colors.textSecondary }}>
                    {addOn.description}
                  </Text>
                </View>
                <Text style={{ color: colors.textPrimary, fontWeight: typography.weight.semibold }}>
                  +₹{addOn.priceInr}
                </Text>
              </Pressable>
            );
          })}
        </View>

        <Text
          style={{
            marginTop: spacing.xl,
            marginBottom: spacing.sm,
            fontWeight: typography.weight.semibold,
            color: colors.textPrimary,
          }}>
          Payment method
        </Text>
        <View style={{ gap: spacing.sm }}>
          {paymentMethods.map((method) => {
            const Icon = PAYMENT_ICONS[method.icon];
            const isSelected = method.id === paymentId;
            return (
              <Pressable
                key={method.id}
                onPress={() => setPaymentId(method.id)}
                style={[
                  styles.paymentRow,
                  {
                    backgroundColor: colors.surface,
                    borderRadius: radii.lg,
                    padding: spacing.md,
                    borderWidth: isSelected ? 1.5 : 0,
                    borderColor: colors.primary,
                  },
                ]}>
                <Icon size={18} color={colors.primary} />
                <Text style={{ marginLeft: spacing.md, flex: 1, color: colors.textPrimary }}>{method.label}</Text>
                {isSelected ? <CheckCircle2 size={18} color={colors.primary} /> : null}
              </Pressable>
            );
          })}
        </View>
      </ScrollView>

      <View style={[styles.footer, { backgroundColor: colors.surface, borderTopColor: colors.border, padding: spacing.lg }]}>
        <View>
          <Text style={{ color: colors.textSecondary, fontSize: typography.size.xs }}>Total</Text>
          <Text style={{ fontSize: typography.size.xl, fontWeight: typography.weight.bold, color: colors.textPrimary }}>
            ₹{total}
          </Text>
        </View>
        <View style={{ flex: 1, marginLeft: spacing.lg }}>
          <Button
            label="Confirm & Dispatch Cleaner"
            loading={submitting}
            disabled={!address || !arrivalSlotId}
            onPress={handleConfirm}
          />
        </View>
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  summaryCard: {},
  summaryHeaderRow: { flexDirection: 'row', alignItems: 'flex-start', justifyContent: 'space-between' },
  row: { flexDirection: 'row', alignItems: 'center', gap: 8 },
  slotRow: { flexDirection: 'row', alignItems: 'center' },
  radioOuter: {
    width: 20,
    height: 20,
    borderRadius: 10,
    borderWidth: 1.5,
    alignItems: 'center',
    justifyContent: 'center',
  },
  radioInner: { width: 10, height: 10, borderRadius: 5 },
  accessRow: { flexDirection: 'row', gap: 8 },
  accessChip: { flex: 1, alignItems: 'center', paddingVertical: 12, paddingHorizontal: 4 },
  input: { borderWidth: 1, paddingHorizontal: 12, paddingVertical: 10 },
  addOnRow: { flexDirection: 'row', alignItems: 'center' },
  paymentRow: { flexDirection: 'row', alignItems: 'center' },
  footer: { flexDirection: 'row', alignItems: 'center', borderTopWidth: 1 },
});

