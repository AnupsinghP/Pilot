import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack, useRouter } from 'expo-router';
import { CheckCircle2, MapPin } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Button } from '@/src/components/Button';
import { addresses } from '@/src/data/addresses';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

export default function BookingAddressScreen() {
  const router = useRouter();
  const { colors, radii, spacing, typography, shadow } = useTheme();
  const draftAddressId = useBookingStore((s) => s.draft.addressId);
  const setDraft = useBookingStore((s) => s.setDraft);
  const [selected, setSelected] = useState(draftAddressId ?? addresses[0]?.id);

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: 'Select address', headerShown: true }} />
      <ScrollView contentContainerStyle={{ padding: spacing.lg, paddingBottom: spacing.xxl }}>
        {addresses.map((address) => {
          const isSelected = address.id === selected;
          return (
            <Pressable
              key={address.id}
              onPress={() => setSelected(address.id)}
              style={[
                styles.card,
                shadow.card,
                {
                  backgroundColor: colors.surface,
                  borderRadius: radii.lg,
                  padding: spacing.md,
                  marginBottom: spacing.md,
                  borderWidth: isSelected ? 1.5 : 0,
                  borderColor: colors.primary,
                },
              ]}>
              <View style={[styles.iconWrap, { backgroundColor: colors.primaryMuted }]}>
                <MapPin size={18} color={colors.primary} />
              </View>
              <View style={{ marginLeft: spacing.md, flex: 1 }}>
                <Text style={{ fontWeight: typography.weight.semibold, color: colors.textPrimary }}>
                  {address.label}
                </Text>
                <Text style={{ color: colors.textSecondary, fontSize: typography.size.sm, marginTop: 2 }}>
                  {address.line1}
                  {address.line2 ? `, ${address.line2}` : ''}, {address.city}
                </Text>
              </View>
              {isSelected ? <CheckCircle2 size={20} color={colors.primary} /> : null}
            </Pressable>
          );
        })}
      </ScrollView>
      <View style={{ padding: spacing.lg }}>
        <Button
          label="Continue"
          disabled={!selected}
          onPress={() => {
            if (!selected) return;
            setDraft({ addressId: selected });
            router.push('/booking/checkout');
          }}
        />
      </View>
    </Screen>
  );
}

const styles = StyleSheet.create({
  card: { flexDirection: 'row', alignItems: 'center' },
  iconWrap: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
});
