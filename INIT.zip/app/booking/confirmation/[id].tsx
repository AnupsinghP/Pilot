import React from 'react';
import { ScrollView, StyleSheet, Text, View } from 'react-native';
import { Stack, useLocalSearchParams, useRouter } from 'expo-router';
import { PartyPopper } from 'lucide-react-native';
import { Screen } from '@/src/components/Screen';
import { Button } from '@/src/components/Button';
import { getServiceById } from '@/src/data/services';
import { useBookingStore } from '@/src/store/bookingStore';
import { useTheme } from '@/src/theme/useTheme';

export default function BookingConfirmationScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { colors, hero, radii, spacing, typography, fonts, shadow } = useTheme();
  const booking = useBookingStore((s) => s.getBooking(id));
  const service = booking ? getServiceById(booking.serviceId) : undefined;

  if (!booking || !service) {
    return (
      <Screen edges={['top']}>
        <View style={{ flex: 1, alignItems: 'center', justifyContent: 'center', padding: spacing.xl }}>
          <Text style={{ color: colors.textSecondary }}>Booking not found.</Text>
        </View>
      </Screen>
    );
  }

  return (
    <Screen edges={['top']}>
      <Stack.Screen options={{ title: 'Booking confirmed', headerShown: true }} />
      <ScrollView contentContainerStyle={{ padding: spacing.lg, alignItems: 'center', paddingTop: spacing.xxl }}>
        <View style={[styles.iconCircle, { backgroundColor: hero.background }]}>
          <PartyPopper size={32} color="#FFFFFF" />
        </View>
        <Text
          style={{
            marginTop: spacing.lg,
            fontSize: 22,
            fontFamily: fonts.headingSemiBold,
            color: colors.textPrimary,
            textAlign: 'center',
          }}>
          Booking confirmed!
        </Text>
        <Text style={{ marginTop: spacing.xs, color: colors.textSecondary, textAlign: 'center' }}>
          {service.name} · {booking.mode === 'instant' ? 'Arriving shortly' : 'Scheduled'}
        </Text>

        <View
          style={[
            styles.otpCard,
            shadow.card,
            { backgroundColor: colors.surface, borderRadius: radii.lg, padding: spacing.lg, marginTop: spacing.xl },
          ]}>
          <Text style={{ fontSize: typography.size.xs, color: colors.textSecondary, textAlign: 'center' }}>
            SHARE THIS OTP WITH YOUR PROFESSIONAL AT ARRIVAL
          </Text>
          <Text
            style={{
              marginTop: spacing.sm,
              fontSize: 32,
              letterSpacing: 8,
              fontWeight: typography.weight.bold,
              color: colors.primary,
              textAlign: 'center',
            }}>
            {booking.otp}
          </Text>
        </View>

        <View style={{ width: '100%', marginTop: spacing.xxl, gap: spacing.sm }}>
          <Button
            label="Track booking"
            onPress={() => router.replace({ pathname: '/booking/[id]/tracking', params: { id: booking.id } })}
          />
          <Button label="Back to home" variant="outline" onPress={() => router.replace('/(tabs)')} />
        </View>
      </ScrollView>
    </Screen>
  );
}

const styles = StyleSheet.create({
  iconCircle: { width: 72, height: 72, borderRadius: 36, alignItems: 'center', justifyContent: 'center' },
  otpCard: { width: '100%', alignItems: 'center' },
});
